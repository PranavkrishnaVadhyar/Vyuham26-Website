# VYUHAM’26 — Cyber Convergence

Vanilla HTML, CSS, and JavaScript festival frontend for Digital University Kerala. The homepage and shared visual system have been rebuilt around the dark cyber-conference direction of the [Dribbble reference](https://dribbble.com/shots/15198421-WebDesign): indigo and violet atmosphere, cyan highlights, large title art, and layered angled presentation panels. VYUHAM branding, red logo, and primary red action color remain in place.

## Run locally

From this folder, run `python -m http.server 8000` and open http://localhost:8000/. The site uses hash routes; event detail pages can be refreshed directly.

## Included

- Responsive redesigned homepage, event archive and detail dossiers, four festival streams, three-day schedule, about, venue, sponsors, contact, FAQ, and participant account shells.
- Existing event records, search, category filters, working detail routes, schedule selectors, mobile navigation, FAQ controls, and countdown.
- Official supplied red VYUHAM emblem and the supplied industrial monolith artwork, now composed as a layered stage visual.
- Selective dark-neumorphic depth on buttons, the festival information banner, CTA banner, countdown, and hero image frame; the rest of the page keeps the flatter editorial hierarchy.
- Accessible focus states, reduced-motion handling, practical forms, and static-build safeguards; authentication and external operations are not simulated.

## Reference and validation

The linked Dribbble shot was inspected in-browser. Its defining characteristics used here are the dark indigo/purple base, cyan/magenta light accents, oversized cyber-style typography, and angled overlapping presentation mockups. The structure and copy are adapted for VYUHAM rather than copied from unrelated branding.

Event-specific photography and confirmed sponsor identities were not supplied, so existing event data and available artwork are used. Verify final schedule changes and sponsor information with official festival communications before publication.
