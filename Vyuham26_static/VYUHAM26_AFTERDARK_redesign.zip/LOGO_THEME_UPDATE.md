# VYUHAM’26 — DRIBBBLE-INSPIRED RED & BLACK REDESIGN

- Rebuilt the homepage hero from a full-bleed text overlay into a split editorial composition: large VYUHAM’26/“THE FUTURE AWAITS” typography and actions beside the original industrial architectural image.
- Applied the requested black, charcoal, crimson, and warm-white tokens; kept neumorphic depth to the countdown, search, filters, form fields, buttons, day selectors, and a few panels.
- Used the supplied VYUHAM red emblem in the header and hero, and retained the AFTERDARK architectural asset for the hero and selected campaign artwork.
- Kept the homepage sequence of introduction, streams, featured events, 3-day schedule, venue, sponsors, and footer; separated venue from sponsors.
- Varied event-archive card spans while preserving the original 36 event records, event detail routes, category filtering, and search. Day controls and the IST countdown continue to use configured source data.
- Preserved vanilla HTML/CSS/JS, mobile navigation, accessible focus styles, reduced-motion support, and static authentication/payment safeguards. Removed obsolete hero and partner/venue CSS rather than layering another theme override.

## Run and verify

Run `python -m http.server 8000` from the project directory and open http://localhost:8000/. Verification notes and limitations are recorded in README.md.
