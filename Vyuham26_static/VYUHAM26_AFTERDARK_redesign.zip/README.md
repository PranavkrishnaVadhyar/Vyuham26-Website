# VYUHAM’26 — AFTERDARK / RED & BLACK

Vanilla HTML, CSS, and JavaScript festival frontend for Digital University Kerala. The visual direction pairs the industrial AFTERDARK monolith image with a split editorial hero, oversized display type, and selective tactile controls in a black and crimson palette.

## Run locally

From this folder, run `python -m http.server 8000` and open http://localhost:8000/. The site uses hash routes; event detail pages can be refreshed directly.

## Included

- Responsive homepage, event archive and detail dossiers, four festival streams, three-day schedule, about, venue, sponsors, contact, FAQ, and participant account shells.
- Existing event records, search, category filters, working detail routes, schedule selectors, mobile navigation, FAQ controls, and countdown.
- Official supplied red VYUHAM emblem, industrial monolith image, split hero layout, selective inset/raised controls, keyboard focus states, reduced-motion handling, and accessible navigation labels.
- Forms and account pages retain clear static-build safeguards; authentication and external operations are not simulated.

## Reference and validation

The linked Dribbble shot was inspected in-browser. Its embedded website uses a dark storefront header and a split campaign hero, with bold stacked type opposite a vivid blue portrait. This build adapts that composition to the requested red/black industrial festival identity without copying the unrelated brand or copy.

The local site was inspected in a desktop browser viewport and at 390px mobile width. The mobile menu opened; event category filtering returned 8 Technology records; searching “Hackathon” narrowed them to 3; an event detail route opened; and the schedule selector switched to Day 02 using existing event data. The registration page states that authentication is disconnected. Browser console error and warning logs were empty during review. Sponsor names/logos and event-specific imagery were not supplied; the archive uses existing event information and the supplied industrial artwork selectively. Confirm official schedules and sponsor details before publication.
