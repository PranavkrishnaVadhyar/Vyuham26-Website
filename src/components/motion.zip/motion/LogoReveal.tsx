"use client";

import Image from "next/image";
import { useRef, forwardRef, useImperativeHandle } from "react";
import { gsap } from "gsap";

export interface LogoRevealHandle {
  addToTimeline: (tl: gsap.core.Timeline) => void;
}

const LogoReveal = forwardRef<LogoRevealHandle>(function LogoReveal(_, ref) {
  const containerRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const taglineRef = useRef<HTMLParagraphElement>(null);
  const scanRef = useRef<HTMLDivElement>(null);
  const glitchRef = useRef<HTMLDivElement>(null);
  const auraRef = useRef<HTMLDivElement>(null);

  useImperativeHandle(ref, () => ({
    addToTimeline(tl: gsap.core.Timeline) {
      const container = containerRef.current;
      const logo = logoRef.current;
      const title = titleRef.current;
      const subtitle = subtitleRef.current;
      const tagline = taglineRef.current;
      const scan = scanRef.current;
      const glitch = glitchRef.current;
      const aura = auraRef.current;
      if (!container || !logo || !title || !subtitle || !tagline) return;

      // ── Reveal ──
      tl.addLabel("reveal", "break+=0.6");

      // Glitch flash effect
      if (glitch) {
        tl.fromTo(
          glitch,
          { opacity: 0, x: 0 },
          { opacity: 0.8, x: 5, duration: 0.05, ease: "none" },
          "reveal"
        );
        tl.to(glitch, { opacity: 0, x: -3, duration: 0.05 }, ">");
        tl.to(glitch, { opacity: 0.6, x: 2, duration: 0.04 }, ">");
        tl.to(glitch, { opacity: 0, x: 0, duration: 0.04 }, ">");
      }

      // Aura glow expands behind logo
      if (aura) {
        tl.fromTo(
          aura,
          { scale: 0, opacity: 0 },
          { scale: 1, opacity: 0.6, duration: 0.8, ease: "power2.out" },
          "reveal"
        );
        // Pulsing aura
        tl.to(
          aura,
          { scale: 1.15, opacity: 0.4, duration: 1.5, ease: "sine.inOut", yoyo: true, repeat: -1 },
          "reveal+=0.8"
        );
      }

      // Logo scales in with overshoot
      tl.fromTo(
        logo,
        { scale: 0.08, opacity: 0, rotation: -30 },
        { scale: 1, opacity: 1, rotation: 0, duration: 0.8, ease: "back.out(1.4)" },
        "reveal+=0.05"
      );

      // Logo glow pulse
      tl.to(
        logo,
        {
          boxShadow: "0 0 60px 20px rgba(200,255,66,0.6)",
          duration: 0.4,
          ease: "power2.out",
        },
        "reveal+=0.4"
      );
      tl.to(
        logo,
        {
          boxShadow: "0 0 30px 10px rgba(200,255,66,0.3)",
          duration: 0.6,
          ease: "sine.inOut",
          yoyo: true,
          repeat: -1,
        },
        ">"
      );

      // Scan line pass over logo
      if (scan) {
        tl.fromTo(
          scan,
          { y: "-100%", opacity: 0.7 },
          { y: "200%", opacity: 0, duration: 0.6, ease: "power1.in" },
          "reveal+=0.3"
        );
      }

      // Title: letter-by-letter clip reveal
      tl.fromTo(
        title,
        { clipPath: "inset(0 100% 0 0)", opacity: 0, y: 10 },
        { clipPath: "inset(0 0% 0 0)", opacity: 1, y: 0, duration: 0.7, ease: "power3.out" },
        "reveal+=0.4"
      );

      // Subtitle with glow
      tl.fromTo(
        subtitle,
        { y: 24, opacity: 0, letterSpacing: "0.5em" },
        { y: 0, opacity: 1, letterSpacing: "0.3em", duration: 0.5, ease: "power2.out" },
        "reveal+=0.75"
      );

      // Tagline reveal
      tl.fromTo(
        tagline,
        { y: 20, opacity: 0, letterSpacing: "0.4em" },
        { y: 0, opacity: 1, letterSpacing: "0.22em", duration: 0.7, ease: "power2.out" },
        "reveal+=1.1"
      );

      // Glow flare wave across tagline
      tl.to(
        tagline,
        { color: "#c8ff42", textShadow: "0 0 12px rgba(200,255,66,0.8)", duration: 0.6, ease: "sine.inOut" },
        "reveal+=1.8"
      );

      // ── Transition: Hold logo & tagline clearly for 2.5s ──
      tl.addLabel("transition", "reveal+=3.8");
    },
  }));

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 z-15 grid place-items-center pointer-events-none"
      aria-hidden="true"
    >
      <div className="relative grid place-items-center text-center">
        {/* Background aura */}
        <div
          ref={auraRef}
          className="absolute w-64 h-64 rounded-full md:w-80 md:h-80"
          style={{
            opacity: 0,
            background: "radial-gradient(circle, rgba(200,255,66,0.25) 0%, rgba(16,185,129,0.1) 40%, transparent 70%)",
            filter: "blur(20px)",
          }}
        />

        {/* Glitch overlay */}
        <div
          ref={glitchRef}
          className="absolute inset-0 pointer-events-none"
          style={{
            opacity: 0,
            background: "linear-gradient(90deg, transparent 30%, rgba(200,255,66,0.3) 35%, transparent 40%)",
            mixBlendMode: "screen",
          }}
        />

        {/* Logo */}
        <div
          ref={logoRef}
          className="intro-emblem-shell relative grid h-32 w-32 place-items-center rounded-full md:h-40 md:w-40"
          style={{ opacity: 0 }}
        >
          <Image
            src="/logo.png"
            alt="Vyuham logo"
            width={128}
            height={128}
            priority
            loading="eager"
            fetchPriority="high"
            className="intro-emblem h-24 w-24 object-contain md:h-32 md:w-32"
          />

          {/* Scan line */}
          <div
            ref={scanRef}
            className="absolute inset-x-0 h-[3px] pointer-events-none"
            style={{
              background: "linear-gradient(90deg, transparent, rgba(200,255,66,0.8), transparent)",
              opacity: 0,
            }}
          />
        </div>

        {/* Title */}
        <h1
          ref={titleRef}
          className="intro-wordmark mt-6 font-display text-[clamp(48px,10vw,112px)] leading-none tracking-[-0.09em] text-paper"
          style={{ opacity: 0 }}
        >
          VYUHAM<span className="text-green">&apos;26</span>
        </h1>

        {/* Subtitle */}
        <p
          ref={subtitleRef}
          className="mt-3 font-mono text-[10px] tracking-[0.3em] text-green"
          style={{ opacity: 0 }}
        >
          TECH FEST 2026
        </p>

        {/* Tagline */}
        <p
          ref={taglineRef}
          className="mt-2 font-mono text-[9px] tracking-[0.22em] text-muted"
          style={{ opacity: 0 }}
        >
          THE FUTURE AWAITS
        </p>
      </div>
    </div>
  );
});

export default LogoReveal;
