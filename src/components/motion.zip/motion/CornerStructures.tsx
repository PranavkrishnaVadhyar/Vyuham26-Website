"use client";

import { useRef, forwardRef, useImperativeHandle } from "react";
import { gsap } from "gsap";

/* ─── 4 Mechanical Corner Structure Groups (more detailed) ─── */
const CLAMPS = [
  {
    id: "tl",
    paths: [
      "M -20 -20 L 50 50 L 78 36 L 58 78 Z",
      "M 35 35 L 68 22 L 82 36 L 52 52 Z",
      "M 15 45 L 40 20 L 48 28 L 23 53 Z",
      "M 5 30 L 25 10 L 30 15 L 10 35 Z",
    ],
    circuits: [
      "M 10 70 L 60 70 L 60 50",
      "M 50 30 L 50 65 L 30 65",
      "M 20 55 L 45 55",
    ],
    bolts: [
      { cx: 55, cy: 55 },
      { cx: 40, cy: 35 },
    ],
    piston: "M -40 -40 L 40 40",
    origin: { x: -500, y: -500 },
    explode: { x: -700, y: -700, rotation: -60 },
  },
  {
    id: "tr",
    paths: [
      "M 220 -20 L 150 50 L 122 36 L 142 78 Z",
      "M 165 35 L 132 22 L 118 36 L 148 52 Z",
      "M 185 45 L 160 20 L 152 28 L 177 53 Z",
      "M 195 30 L 175 10 L 170 15 L 190 35 Z",
    ],
    circuits: [
      "M 190 70 L 140 70 L 140 50",
      "M 150 30 L 150 65 L 170 65",
      "M 180 55 L 155 55",
    ],
    bolts: [
      { cx: 145, cy: 55 },
      { cx: 160, cy: 35 },
    ],
    piston: "M 240 -40 L 160 40",
    origin: { x: 500, y: -500 },
    explode: { x: 700, y: -700, rotation: 60 },
  },
  {
    id: "bl",
    paths: [
      "M -20 220 L 50 150 L 78 164 L 58 122 Z",
      "M 35 165 L 68 178 L 82 164 L 52 148 Z",
      "M 15 155 L 40 180 L 48 172 L 23 147 Z",
      "M 5 170 L 25 190 L 30 185 L 10 165 Z",
    ],
    circuits: [
      "M 10 130 L 60 130 L 60 150",
      "M 50 170 L 50 135 L 30 135",
      "M 20 145 L 45 145",
    ],
    bolts: [
      { cx: 55, cy: 145 },
      { cx: 40, cy: 165 },
    ],
    piston: "M -40 240 L 40 160",
    origin: { x: -500, y: 500 },
    explode: { x: -700, y: 700, rotation: 60 },
  },
  {
    id: "br",
    paths: [
      "M 220 220 L 150 150 L 122 164 L 142 122 Z",
      "M 165 165 L 132 178 L 118 164 L 148 148 Z",
      "M 185 155 L 160 180 L 152 172 L 177 147 Z",
      "M 195 170 L 175 190 L 170 185 L 190 165 Z",
    ],
    circuits: [
      "M 190 130 L 140 130 L 140 150",
      "M 150 170 L 150 135 L 170 135",
      "M 180 145 L 155 145",
    ],
    bolts: [
      { cx: 145, cy: 145 },
      { cx: 160, cy: 165 },
    ],
    piston: "M 240 240 L 160 160",
    origin: { x: 500, y: 500 },
    explode: { x: 700, y: 700, rotation: -60 },
  },
];

export interface CornerStructuresHandle {
  addToTimeline: (tl: gsap.core.Timeline) => void;
}

const CornerStructures = forwardRef<CornerStructuresHandle>(function CornerStructures(_, ref) {
  const svgRef = useRef<SVGSVGElement>(null);
  const groupRefs = useRef<(SVGGElement | null)[]>([]);
  const pistonRefs = useRef<(SVGPathElement | null)[]>([]);
  const sparkRefs = useRef<(SVGCircleElement | null)[]>([]);
  const vibrateIds = useRef<gsap.core.Tween[]>([]);

  useImperativeHandle(ref, () => ({
    addToTimeline(tl: gsap.core.Timeline) {
      tl.addLabel("structures", "ring+=0.3");

      CLAMPS.forEach((clamp, i) => {
        const group = groupRefs.current[i];
        const piston = pistonRefs.current[i];
        const spark = sparkRefs.current[i];
        if (!group || !piston) return;

        const delay = i * 0.14;

        // Piston extends with dash animation
        tl.fromTo(
          piston,
          { opacity: 0, strokeDashoffset: 100 },
          { opacity: 0.8, strokeDashoffset: 0, duration: 0.4, ease: "power1.out" },
          `structures+=${delay}`
        );

        // Clamp flies in with rotation
        tl.fromTo(
          group,
          {
            x: clamp.origin.x,
            y: clamp.origin.y,
            opacity: 0,
            rotation: clamp.origin.x > 0 ? -20 : 20,
            transformOrigin: "100px 100px",
          },
          {
            x: 0, y: 0, opacity: 1, rotation: 0,
            duration: 0.7,
            ease: "power3.out",
            onComplete() {
              // Lock impact: sharp vibration
              const vib = gsap.to(group, {
                x: "+=3", yoyo: true, repeat: 5, duration: 0.03, ease: "power1.inOut",
              });
              vib.then(() => vib.kill());
            },
          },
          `structures+=${delay + 0.05}`
        );

        // Impact spark
        if (spark) {
          tl.fromTo(
            spark,
            { opacity: 0, attr: { r: 2 } },
            { opacity: 1, attr: { r: 8 }, duration: 0.15, ease: "power2.out" },
            `structures+=${delay + 0.7}`
          );
          tl.to(spark, { opacity: 0, attr: { r: 0 }, duration: 0.2 }, ">");
        }
      });

      // Continuous vibration during charging
      tl.add(() => {
        groupRefs.current.forEach((group) => {
          if (!group) return;
          const t = gsap.to(group, {
            x: "+=1.5", y: "+=0.5",
            yoyo: true, repeat: -1,
            duration: 0.06, ease: "power1.inOut",
          });
          vibrateIds.current.push(t);
        });
      }, "charge");

      // Kill vibration at break
      tl.add(() => {
        vibrateIds.current.forEach((t) => t.kill());
        vibrateIds.current = [];
      }, "break");

      // Explosive break-out with rotation
      CLAMPS.forEach((clamp, i) => {
        const group = groupRefs.current[i];
        if (!group) return;

        tl.to(
          group,
          {
            x: clamp.explode.x,
            y: clamp.explode.y,
            rotation: clamp.explode.rotation,
            opacity: 0,
            scale: 0.3,
            duration: 0.45,
            ease: "power4.in",
            transformOrigin: "100px 100px",
          },
          "break+=0.2"
        );
      });
    },
  }));

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 200 200"
      className="absolute inset-0 h-full w-full overflow-visible pointer-events-none"
      aria-hidden="true"
    >
      <defs>
        <filter id="struct-glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="2.5" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="spark-glow" x="-200%" y="-200%" width="500%" height="500%">
          <feGaussianBlur stdDeviation="6" />
        </filter>
      </defs>

      {CLAMPS.map((clamp, i) => (
        <g
          key={`clamp-${clamp.id}`}
          ref={(el) => { groupRefs.current[i] = el; }}
          style={{ opacity: 0 }}
        >
          {/* Hydraulic piston */}
          <path
            ref={(el) => { pistonRefs.current[i] = el; }}
            d={clamp.piston}
            stroke="rgba(16,185,129,0.5)"
            strokeWidth="2.5"
            strokeDasharray="6 4"
            strokeLinecap="round"
            fill="none"
            opacity="0"
          />

          {/* Mechanical body */}
          <g filter="url(#struct-glow)">
            {clamp.paths.map((path, pi) => (
              <path
                key={`path-${clamp.id}-${pi}`}
                d={path}
                fill={pi === 0 ? "#0f172a" : pi === 1 ? "#1e293b" : "#0f172a"}
                stroke="#10b981"
                strokeWidth={pi < 2 ? 1.5 : 1}
                strokeLinejoin="round"
                opacity={pi < 2 ? 1 : 0.7}
              />
            ))}

            {/* Circuit energy lines */}
            {clamp.circuits.map((circuit, ci) => (
              <path
                key={`circuit-${clamp.id}-${ci}`}
                d={circuit}
                stroke="#10b981"
                strokeWidth="0.8"
                opacity="0.5"
                fill="none"
                strokeDasharray="3 3"
              />
            ))}

            {/* Bolt/rivet details */}
            {clamp.bolts.map((bolt, bi) => (
              <g key={`bolt-${clamp.id}-${bi}`}>
                <circle cx={bolt.cx} cy={bolt.cy} r="2.5" fill="#1e293b" stroke="#10b981" strokeWidth="0.5" />
                <circle cx={bolt.cx} cy={bolt.cy} r="1" fill="#10b981" opacity="0.6" />
              </g>
            ))}
          </g>

          {/* Impact spark */}
          <circle
            ref={(el) => { sparkRefs.current[i] = el; }}
            cx={clamp.id.includes("l") ? 60 : 140}
            cy={clamp.id.includes("t") ? 60 : 140}
            r="0"
            fill="#10b981"
            opacity="0"
            filter="url(#spark-glow)"
          />
        </g>
      ))}
    </svg>
  );
});

export default CornerStructures;