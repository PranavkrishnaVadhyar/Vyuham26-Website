"use client";

import { useRef, useEffect, useState, useCallback } from "react";
import { gsap } from "gsap";
import { usePrefersReducedMotion } from "@/hooks/usePrefersReducedMotion";
import StoneSystem, { type StoneSystemHandle } from "@/components/motion/StoneSystem";
import EnergyRing, { type EnergyRingHandle } from "@/components/motion/EnergyRing";
import CornerStructures, { type CornerStructuresHandle } from "@/components/motion/CornerStructures";
import IntroParticleField, { type ParticleFieldHandle } from "@/components/motion/ParticleField3D";
import LogoReveal, { type LogoRevealHandle } from "@/components/motion/LogoReveal";

export default function IntroSequence() {
  const reduceMotion = usePrefersReducedMotion();
  const [dismissed, setDismissed] = useState(false);

  const sectionRef = useRef<HTMLElement>(null);
  const flashRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const scanlineRef = useRef<HTMLDivElement>(null);
  const vignetteRef = useRef<HTMLDivElement>(null);
  const shakeContainerRef = useRef<HTMLDivElement>(null);
  const statusTextRef = useRef<HTMLParagraphElement>(null);
  const statusSubRef = useRef<HTMLParagraphElement>(null);
  const tlRef = useRef<gsap.core.Timeline | null>(null);

  // Sub-component refs
  const stoneRef = useRef<StoneSystemHandle>(null);
  const ringRef = useRef<EnergyRingHandle>(null);
  const structuresRef = useRef<CornerStructuresHandle>(null);
  const particlesRef = useRef<ParticleFieldHandle>(null);
  const logoRef = useRef<LogoRevealHandle>(null);

  const visible = !dismissed && !reduceMotion;

  const dismiss = useCallback(() => {
    if (tlRef.current) {
      tlRef.current.kill();
      tlRef.current = null;
    }
    setDismissed(true);
  }, []);

  const skip = useCallback(() => {
    if (tlRef.current) {
      tlRef.current.progress(1);
    }
  }, []);

  // ── Status text messages mapped to the 16 storyboard panels ──
  const STATUS_MESSAGES = [
    { at: 0.00, text: "01 INITIAL STATE", sub: "FIVE METALLIC SOCKETS APPEAR" },
    { at: 0.06, text: "02 SPACE STONE", sub: "BLUE ENERGY CRYSTAL SEATED" },
    { at: 0.13, text: "03 MIND STONE", sub: "GOLD ENERGY CRYSTAL SEATED" },
    { at: 0.20, text: "04 REALITY STONE", sub: "RED ENERGY CRYSTAL SEATED" },
    { at: 0.27, text: "05 POWER STONE", sub: "PURPLE ENERGY CRYSTAL SEATED" },
    { at: 0.34, text: "06 TIME STONE", sub: "VYUHAM GREEN CRYSTAL ACTIVATED" },
    { at: 0.40, text: "07 ALL STONES SET", sub: "THE POWER AWAKENS" },
    { at: 0.46, text: "08 LOADING INITIATED", sub: "CIRCULAR LOADER FORMS" },
    { at: 0.52, text: "09 STRUCTURES APPROACH", sub: "CORNER CLAMPS INCOMING" },
    { at: 0.58, text: "10 LOCKING", sub: "CONTAINMENT STRUCTURES LOCKED" },
    { at: 0.65, text: "11 LOADING PROGRESS", sub: "ENERGY BUILDING UP" },
    { at: 0.78, text: "12 LOADING COMPLETE", sub: "100% MAXIMUM ENERGY" },
    { at: 0.84, text: "13 BREAKTHROUGH", sub: "CIRCLE BREAKS WITH GREEN LIGHT" },
    { at: 0.89, text: "14 LOGO REVEAL", sub: "VYUHAM'26 APPEARS" },
    { at: 0.94, text: "15 TAGLINE", sub: "THE FUTURE AWAITS" },
    { at: 0.98, text: "16 TRANSITION", sub: "SEAMLESS MOVE TO HOMEPAGE" },
  ];

  // Build and play master timeline
  useEffect(() => {
    if (!visible) return;

    const section = sectionRef.current;
    const flash = flashRef.current;
    const stage = stageRef.current;
    const grid = gridRef.current;
    const scanline = scanlineRef.current;
    const vignette = vignetteRef.current;
    const shakeContainer = shakeContainerRef.current;
    const statusText = statusTextRef.current;
    const statusSub = statusSubRef.current;

    if (!section || !flash || !stage || !shakeContainer) return;

    const buildTimer = requestAnimationFrame(() => {
      const tl = gsap.timeline({
        paused: true,
        onComplete: dismiss,
        onUpdate() {
          // Update status text based on progress
          if (!statusText || !statusSub) return;
          const progress = tl.progress();
          let current = STATUS_MESSAGES[0];
          for (const msg of STATUS_MESSAGES) {
            if (progress >= msg.at) current = msg;
          }
          if (statusText.textContent !== current.text) {
            statusText.textContent = current.text;
            statusSub.textContent = current.sub;
            // Quick flash on text change
            gsap.fromTo(statusText, { opacity: 0.3 }, { opacity: 1, duration: 0.15 });
          }
        },
      });

      // ── Background grid fade in ──
      if (grid) {
        tl.fromTo(grid, { opacity: 0 }, { opacity: 0.15, duration: 1, ease: "power1.out" }, 0);
      }

      // ── Scanline overlay ──
      if (scanline) {
        tl.fromTo(scanline, { opacity: 0 }, { opacity: 0.3, duration: 0.5 }, 0.5);
      }

      // ── Vignette darkens as energy builds ──
      if (vignette) {
        tl.fromTo(vignette, { opacity: 0 }, { opacity: 0.4, duration: 3, ease: "power1.in" }, 1);
      }

      // ── Phase 1: Stones (Frames 01 - 07) ──
      stoneRef.current?.addToTimeline(tl);

      // ── Phase 2: Activate + Ring (Frame 08: LOADING INITIATED) ──
      // Transition background from clean white to dark cyber atmosphere at Frame 08
      tl.to(section, { backgroundColor: "#060c09", duration: 0.6, ease: "power2.inOut" }, "activate");

      ringRef.current?.addToTimeline(tl);

      // ── Phase 3: Structures (Frames 09 & 10: STRUCTURES APPROACH & LOCKING) ──
      structuresRef.current?.addToTimeline(tl);

      // ── Phase 4: Particles (Frames 11 & 12: LOADING PROGRESS & 100%) ──
      particlesRef.current?.addToTimeline(tl);

      // ── Screen shake during charge ──
      tl.to(
        shakeContainer,
        {
          x: "+=2", y: "+=1",
          yoyo: true, repeat: 20,
          duration: 0.06, ease: "power1.inOut",
        },
        "charge+=0.5"
      );

      // Intensifying shake near 100%
      tl.to(
        shakeContainer,
        {
          x: "+=4", y: "+=3",
          yoyo: true, repeat: 10,
          duration: 0.04, ease: "power1.inOut",
        },
        "charge+=2.0"
      );

      // ── Phase 5: Break ──
      // Background → dark
      tl.to(section, { backgroundColor: "#06100b", duration: 0.25, ease: "power2.in" }, "break");

      // Grid and scanline fade out
      if (grid) tl.to(grid, { opacity: 0, duration: 0.2 }, "break");
      if (scanline) tl.to(scanline, { opacity: 0, duration: 0.2 }, "break");

      // Chromatic aberration flash
      tl.to(
        shakeContainer,
        {
          filter: "blur(2px) hue-rotate(90deg) brightness(2)",
          duration: 0.1,
          ease: "power2.out",
        },
        "break+=0.15"
      );
      tl.to(
        shakeContainer,
        { filter: "none", duration: 0.15, ease: "power1.out" },
        "break+=0.25"
      );

      // Green flash burst
      tl.to(flash, { opacity: 0.95, scale: 1.5, duration: 0.2, ease: "power2.out" }, "break+=0.2");
      tl.to(flash, { opacity: 0, scale: 4, duration: 0.4, ease: "power1.out" }, "break+=0.4");

      // Hide stone stage with dramatic shrink
      tl.to(stage, { opacity: 0, scale: 0.3, duration: 0.25, ease: "power3.in" }, "break+=0.15");

      // Big screen shake at break
      tl.to(
        shakeContainer,
        { x: "+=8", y: "-=6", yoyo: true, repeat: 4, duration: 0.04, ease: "power2.inOut" },
        "break+=0.2"
      );

      // Reset shake
      tl.set(shakeContainer, { x: 0, y: 0 }, "break+=0.6");

      // ── Phase 6: Logo reveal ──
      logoRef.current?.addToTimeline(tl);

      // ── Phase 7: Transition ──
      tl.to(section, { opacity: 0, duration: 0.6, ease: "power2.inOut" }, "transition");

      tlRef.current = tl;
      tl.play();
    });

    return () => {
      cancelAnimationFrame(buildTimer);
      if (tlRef.current) {
        tlRef.current.kill();
        tlRef.current = null;
      }
    };
  }, [visible, dismiss]);

  if (!visible) return null;

  return (
    <section
      ref={sectionRef}
      className="intro-cinema"
      aria-label="Vyuham 26 opening sequence"
    >
      {/* Skip button */}
      <button type="button" onClick={skip} className="intro-cinema__skip">
        SKIP INTRO ↗
      </button>

      {/* Background grid */}
      <div
        ref={gridRef}
        className="absolute inset-0 pointer-events-none"
        style={{
          opacity: 0,
          backgroundImage:
            "linear-gradient(rgba(16,185,129,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(16,185,129,0.08) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
        aria-hidden="true"
      />

      {/* Scanline overlay */}
      <div
        ref={scanlineRef}
        className="absolute inset-0 pointer-events-none z-30"
        style={{
          opacity: 0,
          background:
            "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px)",
        }}
        aria-hidden="true"
      />

      {/* Vignette */}
      <div
        ref={vignetteRef}
        className="absolute inset-0 pointer-events-none z-5"
        style={{
          opacity: 0,
          background: "radial-gradient(circle at center, transparent 30%, rgba(0,0,0,0.4) 100%)",
        }}
        aria-hidden="true"
      />

      {/* Shake container wraps everything except skip button */}
      <div ref={shakeContainerRef} className="absolute inset-0 grid place-items-center" style={{ willChange: "transform, filter" }}>
        {/* Particle layer */}
        <IntroParticleField ref={particlesRef} />

        {/* Green flash overlay */}
        <div
          ref={flashRef}
          className="intro-flash"
          aria-hidden="true"
          style={{ opacity: 0, transform: "scale(1)" }}
        />

        {/* Central animation stage */}
        <div ref={stageRef} className="relative z-10 h-[290px] w-[290px] md:h-[350px] md:w-[350px]">
          <StoneSystem ref={stoneRef} />
          <EnergyRing ref={ringRef} />
          <CornerStructures ref={structuresRef} />
        </div>

        {/* Logo reveal layer */}
        <LogoReveal ref={logoRef} />
      </div>

      {/* Status telemetry bar */}
      <div className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-center font-mono">
        <p
          ref={statusTextRef}
          className="text-[11px] font-extrabold tracking-[0.22em] text-slate-800 uppercase transition-colors"
        >
          SYSTEM // STANDBY
        </p>
        <p
          ref={statusSubRef}
          className="mt-1 text-[9px] tracking-[0.16em] text-slate-500"
        >
          AWAITING ENERGY SIGNATURE
        </p>
      </div>
    </section>
  );
}
