"use client";

import { useRef, forwardRef, useImperativeHandle } from "react";
import { gsap } from "gsap";

const RADIUS = 74;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
const INNER_RADIUS = 64;
const INNER_CIRC = 2 * Math.PI * INNER_RADIUS;
const TICK_COUNT = 60;

const TICKS = Array.from({ length: TICK_COUNT }, (_, i) => {
  const angle = (i / TICK_COUNT) * Math.PI * 2 - Math.PI / 2;
  const isMajor = i % 5 === 0;
  const innerR = RADIUS - (isMajor ? 8 : 4);
  const outerR = RADIUS - 1;
  return {
    x1: Number((100 + Math.cos(angle) * innerR).toFixed(4)),
    y1: Number((100 + Math.sin(angle) * innerR).toFixed(4)),
    x2: Number((100 + Math.cos(angle) * outerR).toFixed(4)),
    y2: Number((100 + Math.sin(angle) * outerR).toFixed(4)),
    isMajor,
  };
});

export interface EnergyRingHandle {
  addToTimeline: (tl: gsap.core.Timeline) => void;
}

const EnergyRing = forwardRef<EnergyRingHandle>(function EnergyRing(_, ref) {
  const trackRef = useRef<SVGCircleElement>(null);
  const progressRef = useRef<SVGCircleElement>(null);
  const innerRingRef = useRef<SVGCircleElement>(null);
  const counterRef = useRef<HTMLSpanElement>(null);
  const counterLabelRef = useRef<HTMLSpanElement>(null);
  const arcRefs = useRef<(SVGCircleElement | null)[]>([]);
  const tickGroupRef = useRef<SVGGElement>(null);
  const rotatingGroupRef = useRef<SVGGElement>(null);
  const pulseRingRefs = useRef<(SVGCircleElement | null)[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useImperativeHandle(ref, () => ({
    addToTimeline(tl: gsap.core.Timeline) {
      const track = trackRef.current;
      const progress = progressRef.current;
      const innerRing = innerRingRef.current;
      const counter = counterRef.current;
      const counterLabel = counterLabelRef.current;
      const container = containerRef.current;
      const tickGroup = tickGroupRef.current;
      const rotatingGroup = rotatingGroupRef.current;
      if (!track || !progress || !counter || !container || !innerRing) return;

      // ── Activate: center stone triggers ring ──
      tl.addLabel("activate");

      // Track ring fade in with scale
      tl.fromTo(
        track,
        { opacity: 0, attr: { "stroke-width": 0 }, scale: 0.8, transformOrigin: "100px 100px" },
        { opacity: 1, attr: { "stroke-width": 3.5 }, scale: 1, duration: 0.6, ease: "power2.out" },
        "activate"
      );

      // Inner counter-rotating ring
      tl.fromTo(
        innerRing,
        { opacity: 0, strokeDashoffset: INNER_CIRC },
        { opacity: 0.5, strokeDashoffset: 0, duration: 0.8, ease: "power2.out" },
        "activate+=0.1"
      );

      // Tick marks appear
      if (tickGroup) {
        tl.fromTo(tickGroup, { opacity: 0 }, { opacity: 1, duration: 0.4 }, "activate+=0.2");
      }

      // Progress ring appears
      tl.fromTo(
        progress,
        { opacity: 0, strokeDashoffset: CIRCUMFERENCE },
        { opacity: 1, duration: 0.3, ease: "power1.out" },
        "activate+=0.2"
      );

      // Counter text
      tl.fromTo(
        counter,
        { opacity: 0, scale: 0.3 },
        { opacity: 1, scale: 1, duration: 0.4, ease: "back.out(2)" },
        "activate+=0.3"
      );

      // Counter label
      if (counterLabel) {
        tl.fromTo(
          counterLabel,
          { opacity: 0, y: 5 },
          { opacity: 1, y: 0, duration: 0.3, ease: "power2.out" },
          "activate+=0.5"
        );
      }

      // Start rotating group
      if (rotatingGroup) {
        tl.to(
          rotatingGroup,
          { rotation: 360, duration: 8, ease: "linear", repeat: -1, transformOrigin: "100px 100px" },
          "activate"
        );
      }

      // ── Ring label ──
      tl.addLabel("ring", "activate+=0.6");

      // Energy arcs appear with stagger
      arcRefs.current.forEach((arc, i) => {
        if (!arc) return;
        tl.to(arc, { opacity: 0.6, duration: 0.3, ease: "power1.out" }, `ring+=${i * 0.12}`);
      });

      // ── Charge: 0% → 100% ──
      tl.addLabel("charge", "ring+=0.5");

      const progressProxy = { value: 0 };
      tl.to(
        progressProxy,
        {
          value: 100,
          duration: 3.8,
          ease: "power1.inOut",
          onUpdate() {
            const pct = Math.round(progressProxy.value);
            counter.textContent = `${pct}%`;
            const offset = CIRCUMFERENCE * (1 - pct / 100);
            progress.style.strokeDashoffset = String(offset);

            // Intensify glow at higher percentages
            const glowIntensity = 10 + (pct / 100) * 20;
            progress.style.filter = `drop-shadow(0 0 ${glowIntensity}px #10b981)`;
          },
        },
        "charge"
      );

      // Ring stroke gets thicker during charge
      tl.to(progress, { attr: { "stroke-width": 7.5 }, duration: 3.8, ease: "power1.in" }, "charge");

      // Pulse rings during charge (rhythmic energy waves)
      pulseRingRefs.current.forEach((ring, i) => {
        if (!ring) return;
        tl.fromTo(
          ring,
          { attr: { r: RADIUS - 5 }, opacity: 0.5, strokeWidth: 2 },
          { attr: { r: RADIUS + 35 }, opacity: 0, strokeWidth: 0.5, duration: 1.4, ease: "power2.out", repeat: 3, repeatDelay: 0.3 },
          `charge+=${i * 0.4}`
        );
      });

      // Inner ring counter-rotation accelerates
      tl.to(
        innerRing,
        { strokeDashoffset: -INNER_CIRC * 3, duration: 3.8, ease: "power1.in" },
        "charge"
      );

      // ── Break ──
      tl.addLabel("break", "charge+=3.8");

      // Hold at 100% for impact
      tl.to({}, { duration: 0.5 }, "break");

      // Ring explosion expand + fade
      tl.to(
        container,
        { scale: 4, opacity: 0, duration: 0.5, ease: "power3.in" },
        "break+=0.35"
      );
    },
  }));

  return (
    <div ref={containerRef} className="absolute inset-0 pointer-events-none" style={{ willChange: "transform, opacity" }}>
      <svg viewBox="0 0 200 200" className="h-full w-full overflow-visible">
        <defs>
          <filter id="ring-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Rotating decorative group */}
        <g ref={rotatingGroupRef}>
          {/* Tick marks */}
          <g ref={tickGroupRef} opacity="0">
            {TICKS.map((tick, i) => (
              <line
                key={`tick-${i}`}
                x1={tick.x1} y1={tick.y1}
                x2={tick.x2} y2={tick.y2}
                stroke={tick.isMajor ? "#10b981" : "rgba(16,185,129,0.3)"}
                strokeWidth={tick.isMajor ? 1.5 : 0.5}
                strokeLinecap="round"
              />
            ))}
          </g>
        </g>

        {/* Inner counter-rotating ring */}
        <circle
          ref={innerRingRef}
          cx="100" cy="100" r={INNER_RADIUS}
          fill="none"
          stroke="rgba(16,185,129,0.15)"
          strokeWidth="1"
          strokeDasharray="8 4 2 4"
          transform="rotate(90 100 100)"
          opacity="0"
        />

        {/* Track ring */}
        <circle
          ref={trackRef}
          cx="100" cy="100" r={RADIUS}
          fill="none"
          stroke="rgba(16,185,129,0.2)"
          strokeWidth="3.5"
          opacity="0"
        />

        {/* Progress ring */}
        <circle
          ref={progressRef}
          cx="100" cy="100" r={RADIUS}
          fill="none"
          stroke="#10b981"
          strokeWidth="4.5"
          strokeLinecap="round"
          transform="rotate(-90 100 100)"
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={CIRCUMFERENCE}
          opacity="0"
          filter="url(#ring-glow)"
          style={{ filter: "drop-shadow(0 0 10px #10b981)" }}
        />

        {/* Energy arc circles */}
        {[65, 56, 82].map((r, i) => (
          <circle
            key={`arc-${i}`}
            ref={(el) => { arcRefs.current[i] = el; }}
            cx="100" cy="100" r={r}
            className="intro-arc"
          />
        ))}

        {/* Pulse wave rings */}
        {[0, 1, 2].map((_, i) => (
          <circle
            key={`pulse-wave-${i}`}
            ref={(el) => { pulseRingRefs.current[i] = el; }}
            cx="100" cy="100" r={RADIUS}
            fill="none"
            stroke="#10b981"
            strokeWidth="2"
            opacity="0"
          />
        ))}
      </svg>

      {/* Percentage counter */}
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <span
            ref={counterRef}
            className="block font-mono text-2xl font-black tracking-widest text-[#10b981] [text-shadow:0_0_16px_rgba(16,185,129,0.9)]"
            style={{ opacity: 0 }}
          >
            0%
          </span>
          <span
            ref={counterLabelRef}
            className="block mt-1 font-mono text-[8px] tracking-[0.3em] text-[#10b981] opacity-60"
            style={{ opacity: 0 }}
          >
            ENERGY LEVEL
          </span>
        </div>
      </div>
    </div>
  );
});

export default EnergyRing;
