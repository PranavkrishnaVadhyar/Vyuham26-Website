"use client";

import { useRef, forwardRef, useImperativeHandle } from "react";
import { gsap } from "gsap";

/* ─── Stone Data ─── */
const STONES = [
  {
    id: "space",
    cx: 100, cy: 26, r: 13,
    color: "#1d4ed8", glow: "#3b82f6",
    shape: "M 0 -13 L 9 -9 L 13 -1 L 8 10 L 0 13 L -9 9 L -12 -2 Z",
    facets: [
      { d: "M 0 -13 L 9 -9 L 0 0 Z", fill: "#93c5fd" },
      { d: "M 9 -9 L 13 -1 L 0 0 Z", fill: "#3b82f6" },
      { d: "M 13 -1 L 8 10 L 0 0 Z", fill: "#1d4ed8" },
      { d: "M 8 10 L 0 13 L 0 0 Z", fill: "#1e40af" },
      { d: "M 0 13 L -9 9 L 0 0 Z", fill: "#1e3a8a" },
      { d: "M -9 9 L -12 -2 L 0 0 Z", fill: "#2563eb" },
      { d: "M -12 -2 L 0 -13 L 0 0 Z", fill: "#bfdbfe" },
    ],
  },
  {
    id: "reality",
    cx: 26, cy: 100, r: 13,
    color: "#b91c1c", glow: "#ef4444",
    shape: "M -2 -13 L 9 -9 L 13 1 L 7 11 L -4 13 L -11 6 L -12 -5 Z",
    facets: [
      { d: "M -2 -13 L 9 -9 L 0 0 Z", fill: "#fca5a5" },
      { d: "M 9 -9 L 13 1 L 0 0 Z", fill: "#ef4444" },
      { d: "M 13 1 L 7 11 L 0 0 Z", fill: "#dc2626" },
      { d: "M 7 11 L -4 13 L 0 0 Z", fill: "#991b1b" },
      { d: "M -4 13 L -11 6 L 0 0 Z", fill: "#7f1d1d" },
      { d: "M -11 6 L -12 -5 L 0 0 Z", fill: "#b91c1c" },
      { d: "M -12 -5 L -2 -13 L 0 0 Z", fill: "#f87171" },
    ],
  },
  {
    id: "power",
    cx: 174, cy: 100, r: 13,
    color: "#6b21a8", glow: "#a855f7",
    shape: "M 0 -13 L 10 -7 L 13 3 L 6 12 L -6 12 L -13 3 L -9 -9 Z",
    facets: [
      { d: "M 0 -13 L 10 -7 L 0 0 Z", fill: "#e9d5ff" },
      { d: "M 10 -7 L 13 3 L 0 0 Z", fill: "#c084fc" },
      { d: "M 13 3 L 6 12 L 0 0 Z", fill: "#9333ea" },
      { d: "M 6 12 L -6 12 L 0 0 Z", fill: "#7e22ce" },
      { d: "M -6 12 L -13 3 L 0 0 Z", fill: "#581c87" },
      { d: "M -13 3 L -9 -9 L 0 0 Z", fill: "#6b21a8" },
      { d: "M -9 -9 L 0 -13 L 0 0 Z", fill: "#a855f7" },
    ],
  },
  {
    id: "soul",
    cx: 100, cy: 174, r: 13,
    color: "#b45309", glow: "#f59e0b",
    shape: "M -3 -13 L 8 -10 L 13 0 L 8 11 L -2 13 L -10 8 L -12 -4 Z",
    facets: [
      { d: "M -3 -13 L 8 -10 L 0 0 Z", fill: "#fde68a" },
      { d: "M 8 -10 L 13 0 L 0 0 Z", fill: "#fbbf24" },
      { d: "M 13 0 L 8 11 L 0 0 Z", fill: "#f59e0b" },
      { d: "M 8 11 L -2 13 L 0 0 Z", fill: "#d97706" },
      { d: "M -2 13 L -10 8 L 0 0 Z", fill: "#78350f" },
      { d: "M -10 8 L -12 -4 L 0 0 Z", fill: "#92400e" },
      { d: "M -12 -4 L -3 -13 L 0 0 Z", fill: "#fcd34d" },
    ],
  },
  {
    id: "core",
    cx: 100, cy: 100, r: 26,
    color: "#047857", glow: "#10b981",
    shape: "M 0 -26 L 18 -18 L 26 -3 L 18 19 L 0 26 L -18 19 L -26 -3 L -17 -19 Z",
    facets: [
      { d: "M 0 -26 L 18 -18 L 0 0 Z", fill: "#ffffff" },
      { d: "M 18 -18 L 26 -3 L 0 0 Z", fill: "#a7f3d0" },
      { d: "M 26 -3 L 18 19 L 0 0 Z", fill: "#34d399" },
      { d: "M 18 19 L 0 26 L 0 0 Z", fill: "#10b981" },
      { d: "M 0 26 L -18 19 L 0 0 Z", fill: "#047857" },
      { d: "M -18 19 L -26 -3 L 0 0 Z", fill: "#065f46" },
      { d: "M -26 -3 L -17 -19 L 0 0 Z", fill: "#059669" },
      { d: "M -17 -19 L 0 -26 L 0 0 Z", fill: "#6ee7b7" },
    ],
  },
];

/* Flight origins */
const FLIGHT_ORIGINS = [
  { x: 0, y: -220, rotate: -180 },
  { x: -220, y: 0, rotate: 120 },
  { x: 220, y: 0, rotate: -120 },
  { x: 0, y: 220, rotate: 180 },
  { x: 0, y: -180, rotate: -270 },
];

/* Energy beam connections between stones (after all placed) */
const BEAMS = [
  { from: 0, to: 4 }, // space → core
  { from: 1, to: 4 }, // reality → core
  { from: 2, to: 4 }, // power → core
  { from: 3, to: 4 }, // soul → core
  { from: 0, to: 2 }, // space → power (cross)
  { from: 1, to: 3 }, // reality → soul (cross)
];

export interface StoneSystemHandle {
  addToTimeline: (tl: gsap.core.Timeline) => void;
}

const StoneSystem = forwardRef<StoneSystemHandle>(function StoneSystem(_, ref) {
  const svgRef = useRef<SVGSVGElement>(null);
  const stoneGroupRefs = useRef<(SVGGElement | null)[]>([]);
  const pulseRefs = useRef<(SVGCircleElement | null)[]>([]);
  const socketRefs = useRef<(SVGGElement | null)[]>([]);
  const beamRefs = useRef<(SVGLineElement | null)[]>([]);
  const trailRefs = useRef<(SVGCircleElement | null)[]>([]);
  const shimmerRefs = useRef<(SVGGElement | null)[]>([]);

  useImperativeHandle(ref, () => ({
    addToTimeline(tl: gsap.core.Timeline) {
      const svg = svgRef.current;
      if (!svg) return;

      // Sockets appear with metallic pop + slight rotation
      socketRefs.current.forEach((socket, i) => {
        if (!socket) return;
        tl.fromTo(
          socket,
          { scale: 0, opacity: 0, rotation: -15, transformOrigin: `${STONES[i].cx}px ${STONES[i].cy}px` },
          { scale: 1, opacity: 1, rotation: 0, duration: 0.4, ease: "back.out(2.2)" },
          i * 0.1
        );
      });

      // Each stone: trail → flight → snap → pulse → shimmer
      STONES.forEach((stone, i) => {
        const group = stoneGroupRefs.current[i];
        const pulse = pulseRefs.current[i];
        const trail = trailRefs.current[i];
        const shimmer = shimmerRefs.current[i];
        if (!group) return;

        const origin = FLIGHT_ORIGINS[i];
        const stoneStart = 0.5 + i * 0.6;

        // Energy trail appears first
        if (trail) {
          tl.fromTo(
            trail,
            { opacity: 0, attr: { r: 3 } },
            { opacity: 0.7, attr: { r: 6 }, duration: 0.2, ease: "power1.out" },
            stoneStart - 0.1
          );
        }

        // Flight in with rotation + scale
        tl.fromTo(
          group,
          {
            x: origin.x, y: origin.y,
            rotation: origin.rotate,
            scale: i === 4 ? 3 : 2.2,
            opacity: 0,
            transformOrigin: `${stone.cx}px ${stone.cy}px`,
          },
          {
            x: 0, y: 0, rotation: 0, scale: 1, opacity: 1,
            duration: i === 4 ? 0.8 : 0.55,
            ease: "power3.inOut",
          },
          stoneStart
        );

        // Trail follows and fades
        if (trail) {
          tl.to(trail, { opacity: 0, attr: { r: 0 }, duration: 0.3 }, `>-0.2`);
        }

        // Impact bounce
        tl.to(
          group,
          { scale: 1.18, duration: 0.06, ease: "power2.out", transformOrigin: `${stone.cx}px ${stone.cy}px` },
          `>-0.05`
        );
        tl.to(
          group,
          { scale: 0.95, duration: 0.06, ease: "power2.in", transformOrigin: `${stone.cx}px ${stone.cy}px` },
          ">"
        );
        tl.to(
          group,
          { scale: 1, duration: 0.2, ease: "elastic.out(1.2, 0.35)", transformOrigin: `${stone.cx}px ${stone.cy}px` },
          ">"
        );

        // Double energy pulse ring
        if (pulse) {
          tl.fromTo(
            pulse,
            { attr: { r: stone.r }, opacity: 0.9, strokeWidth: 3 },
            { attr: { r: stone.r + 32 }, opacity: 0, strokeWidth: 0.5, duration: 0.6, ease: "power2.out" },
            `>-0.3`
          );
        }

        // Crystal shimmer (continuous subtle rotation after placement)
        if (shimmer) {
          tl.to(
            shimmer,
            { rotation: 8, duration: 2, ease: "sine.inOut", yoyo: true, repeat: -1, transformOrigin: `${stone.cx}px ${stone.cy}px` },
            `>-0.2`
          );
        }
      });

      // ── Energy beams connecting stones to core ──
      tl.addLabel("stonesComplete");

      beamRefs.current.forEach((beam, i) => {
        if (!beam) return;
        tl.fromTo(
          beam,
          { strokeDashoffset: 200, opacity: 0, strokeWidth: 0.5 },
          {
            strokeDashoffset: 0, opacity: 0.6, strokeWidth: 1.5,
            duration: 0.4,
            ease: "power2.out",
          },
          `stonesComplete+=${i * 0.06}`
        );
        // Pulse the beams
        tl.to(
          beam,
          { opacity: 0.3, strokeWidth: 0.8, duration: 0.8, ease: "sine.inOut", yoyo: true, repeat: -1 },
          ">"
        );
      });

      // Center stone activation pulse
      const centerGroup = stoneGroupRefs.current[4];
      if (centerGroup) {
        tl.to(
          centerGroup,
          { scale: 1.15, duration: 0.3, ease: "power2.out", transformOrigin: "100px 100px" },
          "stonesComplete+=0.3"
        );
        tl.to(
          centerGroup,
          { scale: 1, duration: 0.4, ease: "elastic.out(1, 0.5)", transformOrigin: "100px 100px" },
          ">"
        );
      }

      // ── Break: Stones and sockets shatter radially (Frame 13) ──
      const EXPLODE_VECTORS = [
        { x: 0, y: -500, rot: -180 },  // Space (blue) -> top
        { x: -500, y: 0, rot: -240 },  // Reality (red) -> left
        { x: 500, y: 0, rot: 240 },   // Power (purple) -> right
        { x: 0, y: 500, rot: 180 },   // Soul (yellow) -> bottom
        { x: 0, y: 0, rot: 360 },     // Core (green) -> flare burst
      ];

      STONES.forEach((stone, i) => {
        const group = stoneGroupRefs.current[i];
        const socket = socketRefs.current[i];
        if (!group) return;

        const vec = EXPLODE_VECTORS[i];
        if (i === 4) {
          // Center green core flares up dynamically and shatters
          tl.to(
            group,
            {
              scale: 2.8,
              opacity: 0,
              duration: 0.4,
              ease: "power3.in",
              transformOrigin: "100px 100px",
            },
            "break+=0.15"
          );
        } else {
          tl.to(
            group,
            {
              x: vec.x,
              y: vec.y,
              rotation: vec.rot,
              opacity: 0,
              scale: 0.4,
              duration: 0.5,
              ease: "power4.in",
              transformOrigin: `${stone.cx}px ${stone.cy}px`,
            },
            "break+=0.15"
          );
        }

        if (socket) {
          tl.to(socket, { scale: 1.6, opacity: 0, duration: 0.35, ease: "power2.in" }, "break+=0.15");
        }
      });
    },
  }));

  return (
    <svg
      ref={svgRef}
      viewBox="0 0 200 200"
      className="h-full w-full overflow-visible"
      aria-hidden="true"
    >
      <defs>
        <filter id="socket-bevel" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="1.5" result="blur" />
          <feComposite in2="SourceAlpha" operator="arithmetic" k2="-1" k3="1" result="shadowDiff" />
          <feFlood floodColor="#000000" floodOpacity="0.4" />
          <feComposite in2="shadowDiff" operator="in" />
          <feComposite in2="SourceGraphic" operator="over" />
        </filter>

        {STONES.map((s) => (
          <filter key={`glow-${s.id}`} id={`stone-glow-${s.id}`} x="-80%" y="-80%" width="260%" height="260%">
            <feGaussianBlur stdDeviation="4.5" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        ))}

        <filter id="trail-glow" x="-200%" y="-200%" width="500%" height="500%">
          <feGaussianBlur stdDeviation="8" />
        </filter>
      </defs>

      {/* Socket holes */}
      {STONES.map((s, i) => (
        <g key={`socket-${s.id}`} ref={(el) => { socketRefs.current[i] = el; }} style={{ opacity: 0 }}>
          {/* Outer bevel */}
          <circle cx={s.cx} cy={s.cy} r={s.r + 6} fill="url(#socket-bevel)" className="intro-socket-rim" />
          {/* Inner ring detail */}
          <circle cx={s.cx} cy={s.cy} r={s.r + 3} fill="none" stroke="#b0bec5" strokeWidth="0.5" opacity="0.6" />
          {/* Recessed hole */}
          <circle cx={s.cx} cy={s.cy} r={s.r + 1} className="intro-socket-hole" filter="url(#socket-bevel)" />
          {/* Inner shadow */}
          <circle cx={s.cx} cy={s.cy} r={s.r - 2} fill="#64748b" opacity="0.3" />
        </g>
      ))}

      {/* Energy beams between stones */}
      {BEAMS.map((beam, i) => {
        const from = STONES[beam.from];
        const to = STONES[beam.to];
        return (
          <line
            key={`beam-${i}`}
            ref={(el) => { beamRefs.current[i] = el; }}
            x1={from.cx} y1={from.cy}
            x2={to.cx} y2={to.cy}
            stroke={STONES[beam.to].glow}
            strokeWidth="1"
            strokeDasharray="4 6"
            opacity="0"
            style={{ filter: `drop-shadow(0 0 4px ${STONES[beam.to].glow})` }}
          />
        );
      })}

      {/* Energy trails (glow orbs that follow flight path) */}
      {STONES.map((s, i) => (
        <circle
          key={`trail-${s.id}`}
          ref={(el) => { trailRefs.current[i] = el; }}
          cx={s.cx}
          cy={s.cy}
          r="0"
          fill={s.glow}
          opacity="0"
          filter="url(#trail-glow)"
        />
      ))}

      {/* Stones + pulse rings */}
      {STONES.map((s, i) => (
        <g key={`stone-group-${s.id}`}>
          {/* Pulse ring */}
          <circle
            ref={(el) => { pulseRefs.current[i] = el; }}
            cx={s.cx} cy={s.cy} r={s.r}
            fill="none" stroke={s.glow} strokeWidth="2" opacity="0"
          />

          {/* Stone gemstone */}
          <g
            ref={(el) => { stoneGroupRefs.current[i] = el; }}
            style={{ opacity: 0 }}
            filter={`url(#stone-glow-${s.id})`}
          >
            {/* Outer aura (bigger, more diffuse) */}
            <circle cx={s.cx} cy={s.cy} r={s.r + 10} fill={s.color} opacity="0.25" />
            <circle cx={s.cx} cy={s.cy} r={s.r + 6} fill={s.glow} opacity="0.15" />

            {/* Shimmer rotation group */}
            <g ref={(el) => { shimmerRefs.current[i] = el; }}>
              {/* Faceted body */}
              <g transform={`translate(${s.cx}, ${s.cy})`}>
                <path d={s.shape} fill="#0f172a" opacity="0.35" />
                {s.facets.map((facet, fi) => (
                  <path
                    key={`facet-${s.id}-${fi}`}
                    d={facet.d}
                    fill={facet.fill}
                    stroke="rgba(255,255,255,0.5)"
                    strokeWidth="0.4"
                  />
                ))}
                {/* Core white-hot center */}
                <circle cx="0" cy="0" r={s.r * 0.35} fill="#ffffff" opacity="0.9"
                  style={{ filter: `drop-shadow(0 0 10px ${s.glow})` }} />
                {/* Top specular highlight */}
                <path d={s.facets[0].d} fill="#ffffff" opacity="0.6" />
                {/* Secondary specular */}
                {s.facets[1] && <path d={s.facets[1].d} fill="#ffffff" opacity="0.2" />}
              </g>
            </g>
          </g>
        </g>
      ))}
    </svg>
  );
});

export default StoneSystem;
