"use client";

import { useRef, useEffect, forwardRef, useImperativeHandle, useCallback } from "react";
import { gsap } from "gsap";

const MAX_PARTICLES = 200;
const INITIAL_PARTICLES = 40;

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
  hue: number;
  life: number;
}

export interface ParticleFieldHandle {
  addToTimeline: (tl: gsap.core.Timeline) => void;
}

const IntroParticleField = forwardRef<ParticleFieldHandle>(function IntroParticleField(_, ref) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const stateRef = useRef({
    count: INITIAL_PARTICLES,
    speed: 0.3,
    opacity: 0.3,
    exploding: false,
    centerX: 0,
    centerY: 0,
    active: true,
  });
  const animFrameRef = useRef(0);

  const createParticle = useCallback((cx: number, cy: number, spread: number): Particle => {
    const angle = Math.random() * Math.PI * 2;
    const dist = Math.random() * spread;
    return {
      x: cx + Math.cos(angle) * dist,
      y: cy + Math.sin(angle) * dist,
      vx: (Math.random() - 0.5) * stateRef.current.speed,
      vy: (Math.random() - 0.5) * stateRef.current.speed,
      size: Math.random() * 2.5 + 0.5,
      opacity: Math.random() * stateRef.current.opacity + 0.05,
      hue: Math.random() > 0.5 ? 155 : 80, // emerald or chartreuse
      life: 1,
    };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
      stateRef.current.centerX = rect.width / 2;
      stateRef.current.centerY = rect.height / 2;
    };

    resize();
    window.addEventListener("resize", resize);

    // Initialize particles
    const { centerX, centerY } = stateRef.current;
    particlesRef.current = Array.from({ length: INITIAL_PARTICLES }, () =>
      createParticle(centerX, centerY, 120)
    );

    const animate = () => {
      if (!stateRef.current.active) return;

      const rect = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, rect.width, rect.height);

      const state = stateRef.current;
      const particles = particlesRef.current;

      // Add particles up to current count
      while (particles.length < state.count && particles.length < MAX_PARTICLES) {
        particles.push(createParticle(state.centerX, state.centerY, state.exploding ? 20 : 120));
      }

      // Update and draw
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];

        if (state.exploding) {
          // Radial explosion from center
          const dx = p.x - state.centerX;
          const dy = p.y - state.centerY;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          p.vx = (dx / dist) * 8 + (Math.random() - 0.5) * 2;
          p.vy = (dy / dist) * 8 + (Math.random() - 0.5) * 2;
          p.life -= 0.02;
        } else {
          // Gentle orbital drift around center
          const dx = state.centerX - p.x;
          const dy = state.centerY - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          p.vx += (dy / dist) * 0.02 * state.speed;
          p.vy += (-dx / dist) * 0.02 * state.speed;
          p.vx *= 0.99;
          p.vy *= 0.99;
        }

        p.x += p.vx;
        p.y += p.vy;

        if (p.life <= 0 || p.x < -50 || p.x > rect.width + 50 || p.y < -50 || p.y > rect.height + 50) {
          particles.splice(i, 1);
          continue;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue}, 100%, 65%, ${p.opacity * p.life})`;
        ctx.fill();
      }

      // Draw connections (non-exploding only)
      if (!state.exploding) {
        for (let i = 0; i < particles.length; i++) {
          for (let j = i + 1; j < particles.length; j++) {
            const dx = particles[i].x - particles[j].x;
            const dy = particles[i].y - particles[j].y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 80) {
              ctx.beginPath();
              ctx.moveTo(particles[i].x, particles[i].y);
              ctx.lineTo(particles[j].x, particles[j].y);
              ctx.strokeStyle = `rgba(16, 185, 129, ${0.08 * (1 - dist / 80)})`;
              ctx.lineWidth = 0.5;
              ctx.stroke();
            }
          }
        }
      }

      animFrameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animFrameRef.current);
      stateRef.current.active = false;
    };
  }, [createParticle]);

  useImperativeHandle(ref, () => ({
    addToTimeline(tl: gsap.core.Timeline) {
      const state = stateRef.current;

      // During charge: increase particle count + speed + opacity
      tl.to(
        state,
        {
          count: MAX_PARTICLES,
          speed: 2,
          opacity: 0.7,
          duration: 3.8,
          ease: "power1.in",
        },
        "charge"
      );

      // At break: trigger explosion
      tl.add(() => {
        state.exploding = true;
        // Push a burst of particles from center
        const { centerX, centerY } = state;
        for (let i = 0; i < 60; i++) {
          const angle = Math.random() * Math.PI * 2;
          particlesRef.current.push({
            x: centerX + (Math.random() - 0.5) * 10,
            y: centerY + (Math.random() - 0.5) * 10,
            vx: Math.cos(angle) * (4 + Math.random() * 6),
            vy: Math.sin(angle) * (4 + Math.random() * 6),
            size: Math.random() * 3 + 1,
            opacity: 0.9,
            hue: Math.random() > 0.3 ? 155 : 80,
            life: 1,
          });
        }
      }, "break+=0.1");

      // Fade out canvas
      tl.to(
        canvasRef.current,
        { opacity: 0, duration: 0.6, ease: "power1.out" },
        "break+=0.5"
      );
    },
  }));

  return (
    <canvas
      ref={canvasRef}
      className="intro-particles"
      aria-hidden="true"
    />
  );
});

export default IntroParticleField;
