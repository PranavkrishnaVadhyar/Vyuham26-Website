/**
 * VYUHAM'26 SERVICE WORKER
 * Cache-First for static assets, Network-First for dynamic API calls.
 */

const CACHE_NAME = "vyuham26-static-v1";
const STATIC_ASSETS = [
  "/",
  "/index.html",
  "/css/variables.css",
  "/css/reset.css",
  "/css/layout.css",
  "/css/components.css",
  "/css/animations.css",
  "/assets/favicon.ico",
  "/js/lib/sound.js",
  "/js/lib/auth.js",
  "/js/lib/store.js",
  "/js/components/nav.js",
  "/js/components/footer.js",
  "/js/components/toaster.js",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn("[SW] Cache preload partial error:", err);
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((k) => {
          if (k !== CACHE_NAME) {
            return caches.delete(k);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Bypass cache for backend API requests and Supabase requests
  if (url.pathname.startsWith("/events") || url.pathname.startsWith("/auth") || url.pathname.startsWith("/registrations") || url.hostname.includes("supabase.co") || url.port === "8000") {
    return;
  }

  // Cache-first for local static assets
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((response) => {
        if (!response || response.status !== 200 || response.type !== "basic") {
          return response;
        }
        const toCache = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, toCache);
        });
        return response;
      }).catch(() => {
        // Offline fallback
        return cached;
      });
    })
  );
});
