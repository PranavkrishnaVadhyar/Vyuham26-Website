/**
 * VYUHAM'26 CYBER TERMINAL EMULATOR (Vanilla JS)
 */

import { VyuhamStore } from "../lib/store.js";
import { cyberAudio } from "../lib/sound.js";
import { openAuthModal } from "./auth-modal.js";
import { toast } from "./toaster.js";

let terminalEl = null;
let bodyEl = null;
let inputEl = null;

const HISTORY = [];
let historyIndex = -1;

export function initCyberTerminal() {
  if (terminalEl || typeof document === "undefined") return;

  terminalEl = document.getElementById("cyber-terminal-root");
  if (!terminalEl) {
    terminalEl = document.createElement("div");
    terminalEl.id = "cyber-terminal-root";
    terminalEl.className = "cyber-terminal-overlay";
    document.body.appendChild(terminalEl);
  }

  terminalEl.innerHTML = `
    <div class="terminal-window">
      <div class="terminal-header">
        <div class="terminal-dots">
          <div class="terminal-dot terminal-dot--red" id="term-close-dot" style="cursor:pointer;"></div>
          <div class="terminal-dot terminal-dot--yellow"></div>
          <div class="terminal-dot terminal-dot--green"></div>
        </div>
        <span style="font-weight:700;">VYUHAM-OS v2.6 // SECURITY TERMINAL</span>
        <span style="color: var(--color-muted); font-size:10px;">[ESC to exit]</span>
      </div>

      <div class="terminal-body" id="terminal-body">
        <div class="terminal-line terminal-line--cyan">========================================================</div>
        <div class="terminal-line terminal-line--green">VYUHAM'26 MAINFRAME // TECHNOCITY CAMPUS GRID ACTIVE</div>
        <div class="terminal-line terminal-line--muted">Type <span style="color:#ffffff;">'help'</span> to view available operations.</div>
        <div class="terminal-line terminal-line--cyan">========================================================</div>
      </div>

      <div class="terminal-input-row">
        <span class="terminal-prompt">root@vyuham:~$</span>
        <input type="text" class="terminal-input" id="terminal-input" autocomplete="off" spellcheck="false" autofocus />
      </div>
    </div>
  `;

  bodyEl = document.getElementById("terminal-body");
  inputEl = document.getElementById("terminal-input");

  document.getElementById("term-close-dot")?.addEventListener("click", closeTerminal);

  terminalEl.addEventListener("click", (e) => {
    if (e.target === terminalEl) closeTerminal();
  });

  inputEl?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const cmd = inputEl.value.trim();
      inputEl.value = "";
      if (cmd) {
        HISTORY.push(cmd);
        historyIndex = HISTORY.length;
        handleCommand(cmd);
      }
    } else if (e.key === "ArrowUp") {
      if (historyIndex > 0) {
        historyIndex--;
        inputEl.value = HISTORY[historyIndex] || "";
      }
    } else if (e.key === "ArrowDown") {
      if (historyIndex < HISTORY.length - 1) {
        historyIndex++;
        inputEl.value = HISTORY[historyIndex] || "";
      } else {
        historyIndex = HISTORY.length;
        inputEl.value = "";
      }
    }
  });

  // Global key trigger '?'
  window.addEventListener("keydown", (e) => {
    const isInput = ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName);
    if (e.key === "?" && !isInput && !e.ctrlKey && !e.altKey && !e.metaKey) {
      e.preventDefault();
      toggleTerminal();
    }
    if (e.key === "Escape" && terminalEl.classList.contains("open")) {
      closeTerminal();
    }
  });

  window.addEventListener("open-cyber-terminal", () => openTerminal());
}

function printLine(text, className = "") {
  if (!bodyEl) return;
  const line = document.createElement("div");
  line.className = `terminal-line ${className}`;
  line.innerHTML = text;
  bodyEl.appendChild(line);
  bodyEl.scrollTop = bodyEl.scrollHeight;
}

function handleCommand(cmdRaw) {
  printLine(`<span style="color:var(--color-emerald)">root@vyuham:~$</span> ${cmdRaw}`);
  cyberAudio.playClick();

  const [cmd, ...args] = cmdRaw.toLowerCase().split(/\s+/);

  switch (cmd) {
    case "help":
      printLine("<span style='color:var(--color-cyanic)'>COMMAND REPERTOIRE:</span>");
      printLine("  <span style='color:#fff'>help</span>       - Display this command index");
      printLine("  <span style='color:#fff'>status</span>     - Print core server telemetry & gate status");
      printLine("  <span style='color:#fff'>events</span>     - Query festival events catalog");
      printLine("  <span style='color:#fff'>streams</span>    - Enumerate festival pillars (Tech, Mgmt, Cultural, Esports)");
      printLine("  <span style='color:#fff'>audio</span>      - Toggle cyber synthesizer audio (Mute/Unmute)");
      printLine("  <span style='color:#fff'>whoami</span>     - Inspect active operative credentials");
      printLine("  <span style='color:#fff'>login</span>      - Invoke authentication dialog");
      printLine("  <span style='color:#fff'>clear</span>      - Clear terminal monitor buffer");
      printLine("  <span style='color:#fff'>exit</span>       - Terminate terminal session");
      break;

    case "status":
      const regOpen = VyuhamStore.get("regOpen");
      printLine("<span style='color:var(--color-cyanic)'>[SYSTEM TELEMETRY]</span>");
      printLine("  NODE: Technocity Cluster TVM-01");
      printLine(`  REGISTRATION GATE: ${regOpen ? "<span style='color:var(--color-green)'>OPEN [ACCEPTING ENTRIES]</span>" : "<span style='color:var(--color-danger)'>LOCKED [COMING SOON]</span>"}`);
      printLine("  ENCRYPTION: AES-256 PKCE-ENABLED");
      printLine("  DATABASE: SUPABASE HIGH-AVAILABILITY CLOUD");
      break;

    case "events":
      const evs = VyuhamStore.get("events") || [];
      printLine(`<span style='color:var(--color-mint)'>OFFICIAL EVENTS LISTING (${evs.length} PROTOCOLS):</span>`);
      evs.slice(0, 8).forEach((e) => {
        printLine(`  • [DAY ${e.day}] <span style='color:#fff'>${e.title}</span> — ${e.stream.toUpperCase()} (${e.time})`);
      });
      printLine(`  <span style='color:var(--color-muted)'>... and ${evs.length - 8} more. Use /events page for full dossier.</span>`);
      break;

    case "streams":
      const st = VyuhamStore.get("streams") || [];
      st.forEach((s) => {
        printLine(`  [${s.index}] <span style='color:${s.accent};font-weight:700;'>${s.name}</span>: ${s.line}`);
      });
      break;

    case "audio":
      const muted = cyberAudio.toggleMute();
      VyuhamStore.set("sound", !muted);
      printLine(`AUDIO STATUS: ${muted ? "<span style='color:#ef4444'>MUTED</span>" : "<span style='color:#18c47c'>ACTIVE [SYNTHESIS ONLINE]</span>"}`);
      toast(muted ? "🔇 AUDIO MUTED" : "🔊 AUDIO ONLINE", "info");
      break;

    case "whoami":
      const user = VyuhamStore.get("user");
      if (user) {
        printLine(`<span style='color:var(--color-green)'>OPERATIVE:</span> ${user.name}`);
        printLine(`ID: ${user.vyuhamId} | ROLE: ${user.role.toUpperCase()}`);
        printLine(`EMAIL: ${user.email}`);
      } else {
        printLine("<span style='color:var(--color-muted)'>ANONYMOUS RECONNAISSANCE GUEST. Enter 'login' to authenticate.</span>");
      }
      break;

    case "login":
      openAuthModal();
      printLine("Auth protocol triggered.");
      break;

    case "clear":
      if (bodyEl) bodyEl.innerHTML = "";
      break;

    case "exit":
    case "quit":
      closeTerminal();
      break;

    default:
      printLine(`<span style='color:var(--color-danger)'>COMMAND UNRECOGNIZED:</span> ${cmd}. Enter 'help' for guidance.`, "terminal-line--danger");
      cyberAudio.playAccessDenied();
  }
}

export function openTerminal() {
  initCyberTerminal();
  terminalEl?.classList.add("open");
  cyberAudio.playBeep(440, 0.05);
  setTimeout(() => inputEl?.focus(), 100);
}

export function closeTerminal() {
  terminalEl?.classList.remove("open");
  cyberAudio.playClick();
}

export function toggleTerminal() {
  if (terminalEl?.classList.contains("open")) {
    closeTerminal();
  } else {
    openTerminal();
  }
}
