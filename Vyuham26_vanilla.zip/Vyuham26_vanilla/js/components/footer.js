/**
 * VYUHAM'26 COMPONENT: FOOTER (Vanilla JS)
 */

import { homepage } from "../data/content.js";

export function renderFooter(containerEl) {
  if (!containerEl) return;

  containerEl.innerHTML = `
    <footer class="vyuham-footer">
      <div class="container">
        <div class="footer-grid">
          <!-- Col 1: Brand & Festival Coordinates -->
          <div>
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
              <img src="/assets/vyuham_logo_sm.png" onerror="this.src='/assets/vyuham_logo.png'" style="height:32px;width:auto;" alt="VYUHAM" />
              <div class="nav-brand-title">VYUHAM<span>'26</span></div>
            </div>
            <p style="font-size:13px;color:var(--color-muted);line-height:1.6;max-width:320px;margin-bottom:16px;">
              ${homepage.aboutSupport}
            </p>
            <div style="font-family:var(--font-mono);font-size:11px;color:var(--color-emerald);letter-spacing:0.12em;">
              📍 ${homepage.location}
            </div>
            <div style="font-family:var(--font-mono);font-size:11px;color:var(--color-paper);letter-spacing:0.12em;margin-top:6px;">
              🗓️ ${homepage.dates}
            </div>
          </div>

          <!-- Col 2: Festival Streams -->
          <div class="footer-col">
            <h4>FESTIVAL PILLARS</h4>
            <div class="footer-links">
              <a href="/#streams" class="footer-link">TECH // 24HR Hackathon</a>
              <a href="/#streams" class="footer-link">MANAGEMENT // Crisis Arena</a>
              <a href="/#streams" class="footer-link">CULTURAL // Concert & Runway</a>
              <a href="/#streams" class="footer-link">ESPORTS // Valorant & BGMI</a>
            </div>
          </div>

          <!-- Col 3: Navigation -->
          <div class="footer-col">
            <h4>NAVIGATION</h4>
            <div class="footer-links">
              <a href="/#about" class="footer-link">About Vyuham</a>
              <a href="/#schedule" class="footer-link">Timeline & Beats</a>
              <a href="/#events" class="footer-link">Events Board</a>
              <a href="/#gallery" class="footer-link">Visual Experience</a>
            </div>
          </div>

          <!-- Col 4: Dispatch & Socials -->
          <div class="footer-col">
            <h4>COMMUNICATIONS</h4>
            <div class="footer-links">
              <a href="mailto:${homepage.contact.email}" class="footer-link">${homepage.contact.email}</a>
              <a href="tel:${homepage.contact.phone}" class="footer-link">${homepage.contact.phone}</a>
              <div style="display:flex;gap:12px;margin-top:12px;">
                ${homepage.contact.socials
                  .map(
                    (s) => `
                  <a href="${s.href}" target="_blank" rel="noopener" class="footer-link" style="color:var(--color-mint);">${s.label}</a>
                `
                  )
                  .join("")}
              </div>
            </div>
          </div>
        </div>

        <!-- Footer Bottom Bar -->
        <div class="footer-bottom">
          <div>
            © 2026 DIGITAL UNIVERSITY KERALA. VYUHAM'26 ALL RIGHTS RESERVED.
          </div>
          <div>
            VANILLA HYPERMEDIA PROTOCOL // STATUS: NOMINAL
          </div>
        </div>
      </div>
    </footer>
  `;
}
