/**
 * VYUHAM'26 GLOBAL NOTIFICATION TOASTER (Vanilla JS)
 */

import { cyberAudio } from "../lib/sound.js";

let container = null;

function ensureToasterContainer() {
  if (!container && typeof document !== "undefined") {
    container = document.getElementById("toaster-root");
    if (!container) {
      container = document.createElement("div");
      container.id = "toaster-root";
      container.className = "vyuham-toaster";
      document.body.appendChild(container);
    }
  }
  return container;
}

export function toast(message, type = "info", duration = 4000) {
  const root = ensureToasterContainer();
  if (!root) return;

  const item = document.createElement("div");
  item.className = `toast-item toast-item--${type}`;

  const iconMap = {
    success: "✓",
    error: "✕",
    warning: "⚠",
    info: "ℹ",
  };

  item.innerHTML = `
    <span style="font-weight: 700; color: currentColor;">${iconMap[type] || "•"}</span>
    <span style="flex: 1;">${message}</span>
  `;

  root.appendChild(item);

  // Sound feedback
  if (type === "error") {
    cyberAudio.playAccessDenied();
  } else if (type === "success") {
    cyberAudio.playAccessGranted();
  } else {
    cyberAudio.playBeep(type === "warning" ? 520 : 660, 0.06);
  }

  setTimeout(() => {
    item.style.transition = "opacity 0.4s, transform 0.4s";
    item.style.opacity = "0";
    item.style.transform = "translateX(20px)";
    setTimeout(() => {
      item.remove();
    }, 400);
  }, duration);
}

// Global window access
if (typeof window !== "undefined") {
  window.toast = toast;
}
