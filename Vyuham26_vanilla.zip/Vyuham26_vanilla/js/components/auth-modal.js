/**
 * VYUHAM'26 AUTHENTICATION MODAL DIALOG (Vanilla JS)
 */

import { auth } from "../lib/auth.js";
import { cyberAudio } from "../lib/sound.js";
import { toast } from "./toaster.js";
import { VyuhamStore } from "../lib/store.js";

let modalEl = null;
let currentTab = "login"; // 'login' | 'signup'

export function initAuthModal() {
  if (modalEl || typeof document === "undefined") return;

  modalEl = document.getElementById("auth-modal-root");
  if (!modalEl) {
    modalEl = document.createElement("div");
    modalEl.id = "auth-modal-root";
    modalEl.className = "vyuham-modal-overlay";
    document.body.appendChild(modalEl);
  }

  renderModalContent();

  // Close on backdrop click
  modalEl.addEventListener("click", (e) => {
    if (e.target === modalEl) closeAuthModal();
  });

  // Close on Escape key
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && modalEl.classList.contains("open")) {
      closeAuthModal();
    }
  });

  // Open modal event listener
  window.addEventListener("vyuham:open_auth", () => openAuthModal());
}

function renderModalContent() {
  if (!modalEl) return;

  modalEl.innerHTML = `
    <div class="modal-dialog">
      <button class="modal-close-btn" id="modal-close-btn" aria-label="Close modal">✕</button>

      <div style="text-align: center; margin-bottom: 24px;">
        <span style="font-family: var(--font-mono); font-size: 10px; letter-spacing: 0.3em; color: var(--color-emerald); text-transform: uppercase;">Security Protocol</span>
        <h3 style="font-size: 24px; margin-top: 4px; letter-spacing: 0.05em;">GATE ACCESS // VYUHAM</h3>
      </div>

      <div class="auth-tabs">
        <button class="auth-tab-btn ${currentTab === "login" ? "active" : ""}" id="tab-login-btn">SIGN IN</button>
        <button class="auth-tab-btn ${currentTab === "signup" ? "active" : ""}" id="tab-signup-btn">CREATE IDENTITY</button>
      </div>

      <div id="auth-error-banner" style="display: none; padding: 10px 14px; margin-bottom: 16px; background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.4); border-radius: var(--radius-xs); color: #fca5a5; font-family: var(--font-mono); font-size: 11px;"></div>

      <form id="auth-form">
        ${
          currentTab === "signup"
            ? `
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <input type="text" id="auth-name" class="form-input" placeholder="Operative Name" required />
          </div>
          <div class="form-group">
            <label class="form-label">Institution / College</label>
            <input type="text" id="auth-college" class="form-input" placeholder="e.g. Digital University Kerala" />
          </div>
        `
            : ""
        }

        <div class="form-group">
          <label class="form-label">Email Coordinate</label>
          <input type="email" id="auth-email" class="form-input" placeholder="operative@institution.edu" required />
        </div>

        <div class="form-group">
          <label class="form-label">Access Passphrase</label>
          <input type="password" id="auth-password" class="form-input" placeholder="••••••••" required />
        </div>

        <button type="submit" class="btn-cine btn-cine--solid" style="width: 100%; margin-top: 8px;" id="auth-submit-btn">
          ${currentTab === "login" ? "AUTHENTICATE & ENTER" : "ENROLL OPERATIVE"}
        </button>
      </form>

      <div style="display: flex; align-items: center; gap: 12px; margin: 20px 0;">
        <div style="flex: 1; height: 1px; background: rgba(255,255,255,0.1);"></div>
        <span style="font-family: var(--font-mono); font-size: 10px; color: var(--color-muted);">OR CONTINUE WITH</span>
        <div style="flex: 1; height: 1px; background: rgba(255,255,255,0.1);"></div>
      </div>

      <button type="button" class="oauth-btn" id="auth-google-btn">
        <svg width="14" height="14" viewBox="0 0 24 24"><path fill="#EA4335" d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.8 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.4 9 5 12 5z"/><path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"/><path fill="#FBBC05" d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3s.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12 0 14.8s.7 5.1 1.9 7.5l3.7-2.9z"/><path fill="#34A853" d="M12 23.5c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2-6.4-4.8L1.9 17C3.7 20.8 7.5 23.5 12 23.5z"/></svg>
        GOOGLE SINGLE SIGN-ON
      </button>
    </div>
  `;

  // Attach event handlers
  document.getElementById("modal-close-btn")?.addEventListener("click", closeAuthModal);

  document.getElementById("tab-login-btn")?.addEventListener("click", () => {
    currentTab = "login";
    renderModalContent();
    cyberAudio.playClick();
  });

  document.getElementById("tab-signup-btn")?.addEventListener("click", () => {
    currentTab = "signup";
    renderModalContent();
    cyberAudio.playClick();
  });

  document.getElementById("auth-google-btn")?.addEventListener("click", () => {
    cyberAudio.playClick();
    auth.loginWithGoogle();
  });

  const form = document.getElementById("auth-form");
  form?.addEventListener("submit", async (e) => {
    e.preventDefault();
    cyberAudio.playClick();

    const submitBtn = document.getElementById("auth-submit-btn");
    const errorBanner = document.getElementById("auth-error-banner");
    const email = document.getElementById("auth-email").value;
    const password = document.getElementById("auth-password").value;

    if (submitBtn) submitBtn.textContent = "VERIFYING CREDENTIALS…";
    if (errorBanner) errorBanner.style.display = "none";

    try {
      if (currentTab === "login") {
        const res = await auth.login(email, password);
        if (!res.success) throw new Error(res.error);
        toast("ACCESS GRANTED // Identity Confirmed", "success");
        closeAuthModal();
      } else {
        const name = document.getElementById("auth-name")?.value || "";
        const college = document.getElementById("auth-college")?.value || "";
        const res = await auth.signup({ email, password, name, college });
        if (!res.success) throw new Error(res.error);
        toast("OPERATIVE ENROLLED // Verification dispatched", "success");
        closeAuthModal();
      }
    } catch (err) {
      if (errorBanner) {
        errorBanner.textContent = err.message || "Authentication rejected.";
        errorBanner.style.display = "block";
      }
      toast(err.message || "Auth error", "error");
    } finally {
      if (submitBtn) {
        submitBtn.textContent = currentTab === "login" ? "AUTHENTICATE & ENTER" : "ENROLL OPERATIVE";
      }
    }
  });
}

export function openAuthModal(tab = "login") {
  initAuthModal();
  currentTab = tab;
  renderModalContent();
  modalEl?.classList.add("open");
  cyberAudio.playBeep(880, 0.08);
}

export function closeAuthModal() {
  modalEl?.classList.remove("open");
  cyberAudio.playClick();
}
