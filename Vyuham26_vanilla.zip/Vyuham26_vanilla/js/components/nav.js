/**
 * VYUHAM'26 MAIN NAVIGATION HEADER (Vanilla JS)
 */

import { VyuhamStore } from "../lib/store.js";
import { cyberAudio } from "../lib/sound.js";
import { openAuthModal } from "./auth-modal.js";
import { openTerminal } from "./cyber-terminal.js";
import { toast } from "./toaster.js";
import { auth } from "../lib/auth.js";

export function renderNav(containerEl) {
  if (!containerEl) return;

  function update() {
    const user = VyuhamStore.get("user");
    const sound = VyuhamStore.get("sound");

    containerEl.innerHTML = `
      <nav class="vyuham-nav" id="main-nav">
        <div class="container nav-inner">
          <a href="/" class="nav-brand">
            <img src="/assets/vyuham_logo_sm.png" onerror="this.src='/assets/vyuham_logo.png'" alt="VYUHAM'26" />
            <div class="nav-brand-title">VYUHAM<span>'26</span></div>
          </a>

          <div class="nav-links">
            <a href="/#about" class="nav-link">ABOUT</a>
            <a href="/#streams" class="nav-link">STREAMS</a>
            <a href="/#schedule" class="nav-link">SCHEDULE</a>
            <a href="/#events" class="nav-link">EVENTS</a>
            <a href="/#gallery" class="nav-link">GALLERY</a>
          </div>

          <div class="nav-actions">
            <!-- Audio Toggle Button -->
            <button class="btn-icon" id="nav-audio-btn" title="Toggle Synthesizer Audio (Key: M)">
              ${sound ? "🔊" : "🔇"}
            </button>

            <!-- Terminal Button -->
            <button class="btn-icon" id="nav-terminal-btn" title="Open Cyber Terminal (Key: ?)">
              ?
            </button>

            <!-- User Auth / Profile Button -->
            ${
              user
                ? `
              <div style="display:flex;align-items:center;gap:8px;">
                <button class="btn-cine btn-cine--solid" id="nav-user-btn" style="padding: 8px 16px;">
                  OPERATIVE // ${user.name.split(" ")[0].toUpperCase()}
                </button>
                <button class="btn-icon" id="nav-logout-btn" title="Log Out" style="color:var(--color-danger);">
                  ⏻
                </button>
              </div>
            `
                : `
              <button class="btn-cine" id="nav-login-btn">
                GATE ACCESS
              </button>
            `
            }

            <!-- Mobile Hamburger -->
            <button class="btn-icon nav-hamburger" id="nav-hamburger-btn">
              ☰
            </button>
          </div>
        </div>
      </nav>

      <!-- Mobile Drawer Menu -->
      <div class="mobile-drawer" id="mobile-drawer">
        <div class="mobile-drawer-header">
          <div class="nav-brand-title">VYUHAM<span>'26</span></div>
          <button class="btn-icon" id="mobile-close-btn">✕</button>
        </div>
        <div class="mobile-nav-links">
          <a href="/#about" class="nav-link mobile-link">ABOUT</a>
          <a href="/#streams" class="nav-link mobile-link">STREAMS</a>
          <a href="/#schedule" class="nav-link mobile-link">SCHEDULE</a>
          <a href="/#events" class="nav-link mobile-link">EVENTS</a>
          <a href="/#gallery" class="nav-link mobile-link">GALLERY</a>
        </div>
        <div style="margin-top: auto; padding-top: 32px; border-top: 1px solid rgba(255,255,255,0.1);">
          ${
            user
              ? `<div style="font-family:var(--font-mono);font-size:12px;color:var(--color-green);">LOGGED IN AS: ${user.name}</div>`
              : `<button class="btn-cine btn-cine--solid" id="mobile-login-btn" style="width:100%;">AUTHENTICATE</button>`
          }
        </div>
      </div>
    `;

    // Attach listeners
    document.getElementById("nav-audio-btn")?.addEventListener("click", () => {
      const muted = cyberAudio.toggleMute();
      VyuhamStore.set("sound", !muted);
      toast(muted ? "🔇 Audio Muted" : "🔊 Audio Synthesizer Active", "info");
    });

    document.getElementById("nav-terminal-btn")?.addEventListener("click", () => {
      openTerminal();
    });

    document.getElementById("nav-login-btn")?.addEventListener("click", () => {
      cyberAudio.playClick();
      openAuthModal("login");
    });

    document.getElementById("mobile-login-btn")?.addEventListener("click", () => {
      document.getElementById("mobile-drawer")?.classList.remove("open");
      openAuthModal("login");
    });

    document.getElementById("nav-logout-btn")?.addEventListener("click", async () => {
      cyberAudio.playClick();
      await auth.logout();
      toast("LOGGED OUT // Session Terminated", "info");
    });

    // Mobile menu toggle
    const drawer = document.getElementById("mobile-drawer");
    document.getElementById("nav-hamburger-btn")?.addEventListener("click", () => {
      drawer?.classList.add("open");
      cyberAudio.playClick();
    });
    document.getElementById("mobile-close-btn")?.addEventListener("click", () => {
      drawer?.classList.remove("open");
    });
    document.querySelectorAll(".mobile-link").forEach((l) => {
      l.addEventListener("click", () => drawer?.classList.remove("open"));
    });
  }

  update();

  // Scroll appearance
  window.addEventListener("scroll", () => {
    const nav = document.getElementById("main-nav");
    if (nav) {
      if (window.scrollY > 30) {
        nav.classList.add("scrolled");
      } else {
        nav.classList.remove("scrolled");
      }
    }
  });

  // Re-render when store updates user or sound
  VyuhamStore.subscribe("user", () => update());
  VyuhamStore.subscribe("sound", () => update());
}
