/**
 * VYUHAM'26 LIVE BROADCAST ANNOUNCEMENT TICKER
 */

import { VyuhamStore } from "../lib/store.js";

export function renderBroadcastTicker(targetEl) {
  if (!targetEl) return;

  const announcements = VyuhamStore.get("announcements") || [];
  if (!announcements.length) return;

  // Duplicate list to achieve continuous infinite marquee loop
  const marqueeItems = [...announcements, ...announcements]
    .map(
      (a) => `
    <span class="ticker-item">
      <span class="ticker-sep">//</span>
      <span style="color: var(--color-mint); font-weight: 600;">${a.title}</span>
      <span style="color: var(--color-muted); font-size: 10px;">[${a.date}]</span>
    </span>
  `
    )
    .join("");

  targetEl.innerHTML = `
    <div class="broadcast-ticker">
      <div class="ticker-label">
        <span class="signal-dot anim-blink" style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#18c47c;"></span>
        <span>VYUHAM LIVE //</span>
      </div>
      <div class="ticker-track-wrap">
        <div class="ticker-track">
          ${marqueeItems}
        </div>
      </div>
    </div>
  `;
}
