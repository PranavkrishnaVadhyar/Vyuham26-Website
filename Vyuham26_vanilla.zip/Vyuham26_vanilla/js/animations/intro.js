/**
 * VYUHAM'26 CINEMATIC INTRO SEQUENCE (Vanilla JS + GSAP)
 */

import { introChapters } from "../data/content.js";
import { cyberAudio } from "../lib/sound.js";
import { lockScroll } from "../lib/scroll.js";

export function runCinematicIntro(onComplete) {
  // Check if user has already seen the intro this session
  try {
    if (sessionStorage.getItem("vyuham26:seen")) {
      if (typeof onComplete === "function") onComplete();
      return;
    }
  } catch (e) {}

  lockScroll(true);

  // Build Intro Overlay DOM
  const root = document.createElement("div");
  root.id = "cinematic-intro-root";
  root.style.cssText = `
    position: fixed;
    inset: 0;
    z-index: 99999;
    background: #020403;
    overflow: hidden;
    user-select: none;
  `;

  root.innerHTML = `
    <!-- Top & Bottom Film Letterbox Bars -->
    <div class="intro-bar intro-bar--top" style="position:absolute;top:0;left:0;right:0;height:7vh;background:#000;z-index:10;transform-origin:top;"></div>
    <div class="intro-bar intro-bar--bottom" style="position:absolute;bottom:0;left:0;right:0;height:7vh;background:#000;z-index:10;transform-origin:bottom;"></div>

    <!-- Skip Button -->
    <button id="intro-skip-btn" style="position:absolute;top:24px;right:24px;z-index:20;font-family:var(--font-mono);font-size:10px;letter-spacing:0.24em;color:rgba(255,255,255,0.6);background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.15);padding:8px 16px;border-radius:4px;cursor:pointer;text-transform:uppercase;">
      SKIP SEQUENCE [ESC]
    </button>

    <!-- Chapter Slides Container -->
    <div id="intro-slides" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;">
      <!-- Opening Tagline -->
      <div id="intro-line-open" style="position:absolute;text-align:center;opacity:0;">
        <span style="font-family:var(--font-mono);font-size:12px;letter-spacing:0.38em;color:var(--color-emerald);text-transform:uppercase;display:block;margin-bottom:8px;">TRANSMISSION ACTIVE</span>
        <h2 style="font-size:clamp(32px, 6vw, 68px);font-weight:800;letter-spacing:-0.02em;color:#ffffff;line-height:1;">
          THE WORLD IS CHANGING.
        </h2>
      </div>

      <!-- Chapter Plates -->
      ${introChapters
        .map(
          (c, idx) => `
        <div class="intro-chapter intro-chapter-${idx}" style="position:absolute;inset:0;opacity:0;">
          <img class="intro-plate" src="${c.image}" style="width:100%;height:100%;object-fit:cover;filter:brightness(0.38) contrast(1.2) saturate(0.8);" />
          <div style="position:absolute;inset:0;background:radial-gradient(circle, transparent 20%, rgba(2,4,3,0.85) 90%);"></div>
          <div style="position:absolute;bottom:14vh;left:8vw;z-index:5;">
            <div style="font-family:var(--font-mono);font-size:11px;letter-spacing:0.34em;color:var(--color-emerald);margin-bottom:4px;">${c.sub}</div>
            <h2 style="font-size:clamp(44px, 8vw, 96px);font-weight:800;letter-spacing:-0.03em;color:#ffffff;line-height:0.9;">${c.word}</h2>
          </div>
        </div>
      `
        )
        .join("")}

      <!-- Final Logo Reveal -->
      <div id="intro-logo-reveal" style="position:absolute;text-align:center;opacity:0;z-index:5;">
        <img src="/assets/vyuham_logo.png" style="height:clamp(70px, 12vw, 120px);margin:0 auto 16px;filter:drop-shadow(0 0 32px rgba(24,196,124,0.6));" />
        <h1 style="font-size:clamp(40px, 8vw, 84px);font-weight:800;letter-spacing:0.1em;color:#ffffff;">
          VYUHAM<span style="color:var(--color-emerald);">'26</span>
        </h1>
        <div style="width:120px;height:1px;background:var(--color-emerald);margin:16px auto;"></div>
        <p style="font-family:var(--font-mono);font-size:11px;letter-spacing:0.3em;color:var(--color-paper);text-transform:uppercase;">
          NATIONAL-LEVEL TECHNO-CULTURAL FEST
        </p>
      </div>
    </div>
  `;

  document.body.appendChild(root);

  let finished = false;
  const finish = () => {
    if (finished) return;
    finished = true;
    try { sessionStorage.setItem("vyuham26:seen", "1"); } catch (e) {}
    lockScroll(false);

    if (window.gsap) {
      window.gsap.to(root, {
        opacity: 0,
        scale: 1.05,
        duration: 0.8,
        ease: "power2.inOut",
        onComplete: () => {
          root.remove();
          if (typeof onComplete === "function") onComplete();
        },
      });
    } else {
      root.remove();
      if (typeof onComplete === "function") onComplete();
    }
  };

  document.getElementById("intro-skip-btn")?.addEventListener("click", finish);
  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") finish();
  });

  // Run GSAP Timeline
  if (typeof window.gsap !== "undefined") {
    const tl = window.gsap.timeline({ onComplete: finish });

    // 1. Line Open
    tl.to("#intro-line-open", { opacity: 1, duration: 1, ease: "power2.out" }, 0.3);
    tl.to("#intro-line-open", { opacity: 0, scale: 1.08, filter: "blur(12px)", duration: 0.7, ease: "power2.in" }, 2.0);

    // 2. Chapter Cuts
    let cursor = 2.8;
    introChapters.forEach((c, idx) => {
      const seg = (c.hold / 1000) * 0.85;
      const sel = `.intro-chapter-${idx}`;
      tl.set(sel, { opacity: 1 }, cursor);
      tl.fromTo(`${sel} .intro-plate`, { scale: 1.15, filter: "blur(8px)" }, { scale: 1.02, filter: "blur(0px)", duration: seg * 1.3, ease: "power2.out" }, cursor);
      tl.to(sel, { opacity: 0, duration: 0.25, ease: "power2.in" }, cursor + seg);
      cursor += seg;
    });

    // 3. Final Logo Burst
    tl.set("#intro-logo-reveal", { opacity: 1 }, cursor);
    tl.fromTo("#intro-logo-reveal", { scale: 1.2, filter: "blur(20px)" }, { scale: 1, filter: "blur(0px)", duration: 1.6, ease: "expo.out" }, cursor);
    tl.to("#intro-logo-reveal", { opacity: 0, filter: "blur(14px)", duration: 0.8, ease: "power2.in" }, cursor + 2.2);
  } else {
    setTimeout(finish, 2000);
  }
}
