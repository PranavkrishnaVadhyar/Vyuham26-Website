/**
 * VYUHAM'26 SCROLLTRIGGER BINDINGS & PROGRESS RAIL
 */

export function initScrollProgress() {
  const rail = document.createElement("div");
  rail.id = "scroll-progress-rail";
  rail.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    z-index: 999;
    pointer-events: none;
    background: transparent;
  `;
  rail.innerHTML = `
    <div id="scroll-progress-bar" style="height:100%;width:0%;background:linear-gradient(90deg, rgba(11,90,60,0.8), #18c47c);box-shadow:0 0 12px rgba(24,196,124,0.8);transform-origin:left;"></div>
  `;
  document.body.appendChild(rail);

  const bar = document.getElementById("scroll-progress-bar");

  window.addEventListener("scroll", () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const progress = max > 0 ? (window.scrollY / max) * 100 : 0;
    if (bar) bar.style.width = `${progress.toFixed(2)}%`;
  }, { passive: true });
}

export function initSectionAnimations() {
  if (typeof window.gsap === "undefined" || typeof window.ScrollTrigger === "undefined") {
    return;
  }

  window.gsap.registerPlugin(window.ScrollTrigger);

  // Animate glass cards entering viewport
  document.querySelectorAll(".glass-card").forEach((card) => {
    window.gsap.fromTo(
      card,
      { opacity: 0, y: 30 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power2.out",
        scrollTrigger: {
          trigger: card,
          start: "top 90%",
          toggleActions: "play none none none",
        },
      }
    );
  });
}
