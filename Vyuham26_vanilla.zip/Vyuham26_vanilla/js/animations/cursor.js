/**
 * VYUHAM'26 CINEMATIC CURSOR (Desktop Fine Pointer Only)
 */

export function initCinematicCursor() {
  if (typeof window === "undefined" || window.matchMedia("(pointer: coarse)").matches) {
    return;
  }

  let dot = document.getElementById("cursor-dot");
  let ring = document.getElementById("cursor-ring");

  if (!dot || !ring) {
    const wrap = document.createElement("div");
    wrap.id = "cinematic-cursor-wrap";
    wrap.innerHTML = `
      <div id="cursor-dot" style="position:fixed;top:0;left:0;width:5px;height:5px;background:#2ee59d;border-radius:50%;pointer-events:none;z-index:9999;transform:translate(-50%,-50%);box-shadow:0 0 10px #2ee59d;"></div>
      <div id="cursor-ring" style="position:fixed;top:0;left:0;width:34px;height:34px;border:1px solid rgba(46,229,157,0.5);border-radius:50%;pointer-events:none;z-index:9998;transform:translate(-50%,-50%);transition:opacity 0.2s,border-color 0.2s;"></div>
    `;
    document.body.appendChild(wrap);
    dot = document.getElementById("cursor-dot");
    ring = document.getElementById("cursor-ring");
  }

  const s = { x: innerWidth / 2, y: innerHeight / 2, rx: innerWidth / 2, ry: innerHeight / 2, scale: 1 };
  let targetScale = 1;
  let raf = 0;

  const onMove = (e) => {
    s.x = e.clientX;
    s.y = e.clientY;
    const hoverEl = e.target?.closest?.("a, button, input, textarea, select, [role='button'], .glass-card");
    targetScale = hoverEl ? 1.8 : 1;
    if (ring) {
      ring.style.borderColor = hoverEl ? "rgba(46,229,157,0.9)" : "rgba(46,229,157,0.4)";
    }
  };

  const loop = () => {
    s.rx += (s.x - s.rx) * 0.16;
    s.ry += (s.y - s.ry) * 0.16;
    s.scale += (targetScale - s.scale) * 0.14;

    if (dot) {
      dot.style.transform = `translate3d(${s.x}px, ${s.y}px, 0) translate(-50%,-50%)`;
    }
    if (ring) {
      ring.style.transform = `translate3d(${s.rx}px, ${s.ry}px, 0) translate(-50%,-50%) scale(${s.scale.toFixed(3)})`;
    }

    raf = requestAnimationFrame(loop);
  };

  window.addEventListener("pointermove", onMove, { passive: true });
  raf = requestAnimationFrame(loop);

  return () => {
    window.removeEventListener("pointermove", onMove);
    cancelAnimationFrame(raf);
  };
}
