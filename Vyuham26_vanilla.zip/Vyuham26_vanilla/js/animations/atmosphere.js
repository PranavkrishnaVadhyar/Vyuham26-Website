/**
 * VYUHAM'26 ATMOSPHERE ENGINE (Canvas-based Volumetric Dust & Energy Motes)
 */

export function initAtmosphere(canvasEl, options = {}) {
  if (!canvasEl) return;
  const ctx = canvasEl.getContext("2d", { alpha: true });
  if (!ctx) return;

  const mobile = window.innerWidth < 768;
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const dpr = Math.min(window.devicePixelRatio || 1, mobile ? 1.5 : 2);

  let w = 0;
  let h = 0;
  let raf = 0;
  let running = true;

  const count = reduced ? 20 : mobile ? 36 : 95;
  const particles = [];

  // Pre-render glowing bokeh sprite for extreme 60fps performance
  const makeSprite = (color) => {
    const s = document.createElement("canvas");
    s.width = s.height = 64;
    const c = s.getContext("2d");
    const g = c.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, color);
    g.addColorStop(0.35, color.replace(/[\d.]+\)$/, "0.35)"));
    g.addColorStop(1, color.replace(/[\d.]+\)$/, "0)"));
    c.fillStyle = g;
    c.fillRect(0, 0, 64, 64);
    return s;
  };

  const spriteDust = makeSprite("rgba(206,224,215,0.85)");
  const spriteGreen = makeSprite("rgba(70,238,160,0.85)");

  const resize = () => {
    w = window.innerWidth;
    h = window.innerHeight;
    canvasEl.width = Math.floor(w * dpr);
    canvasEl.height = Math.floor(h * dpr);
    canvasEl.style.width = `${w}px`;
    canvasEl.style.height = `${h}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  const seed = () => {
    particles.length = 0;
    for (let i = 0; i < count; i++) {
      const z = Math.random();
      particles.push({
        x: Math.random() * w,
        y: Math.random() * h,
        z,
        r: (0.7 + z * 2.4) * (mobile ? 0.8 : 1),
        vx: (Math.random() - 0.5) * 0.12 * (0.3 + z),
        vy: -(0.06 + Math.random() * 0.2) * (0.3 + z),
        a: 0.08 + Math.random() * 0.32,
        hue: Math.random() > 0.8 ? 1 : 0,
      });
    }
  };

  resize();
  seed();
  window.addEventListener("resize", resize);

  let t = 0;
  const loop = () => {
    if (!running) return;
    t += 0.0035;
    ctx.clearRect(0, 0, w, h);
    ctx.globalCompositeOperation = "screen";

    for (const p of particles) {
      p.x += p.vx + Math.sin(t + p.y * 0.004) * 0.15 * p.z;
      p.y += p.vy;
      if (p.y < -30) {
        p.y = h + 20;
        p.x = Math.random() * w;
      }
      if (p.x < -30) p.x = w + 20;
      if (p.x > w + 30) p.x = -20;

      const sz = p.r * 18;
      ctx.globalAlpha = p.a * (0.4 + p.z * 0.6);
      ctx.drawImage(p.hue ? spriteGreen : spriteDust, p.x - sz / 2, p.y - sz / 2, sz, sz);
    }

    raf = requestAnimationFrame(loop);
  };

  raf = requestAnimationFrame(loop);

  return () => {
    running = false;
    cancelAnimationFrame(raf);
    window.removeEventListener("resize", resize);
  };
}
