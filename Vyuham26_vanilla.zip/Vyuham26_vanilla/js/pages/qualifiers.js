/**
 * VYUHAM'26 TOURNAMENT QUALIFIERS LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

const qualifiers = [
  {
    title: "E-Football Tournament",
    stream: "ESPORTS",
    prize: "₹5,000",
    regFee: "₹50 / HEAD",
    date: "25 OCT 2026",
    format: "ONLINE DOUBLE ELIMINATION",
    rounds: [
      { round: "Round of 64", date: "25 Oct · 06:00 PM IST", status: "PENDING ROOM CODE" },
      { round: "Quarterfinals", date: "26 Oct · 07:00 PM IST", status: "SCHEDULED" },
      { round: "LAN Finals", date: "31 Oct · DUK Technocity", status: "ON-CAMPUS STAGE" },
    ],
  },
  {
    title: "Valorant Swiss Qualifier",
    stream: "ESPORTS",
    prize: "₹10,000",
    regFee: "₹250 / SQUAD",
    date: "26 OCT 2026",
    format: "SWISS SYSTEM 5-ROUNDS",
    rounds: [
      { round: "Swiss Stage R1-R3", date: "26 Oct · 04:00 PM IST", status: "MAP VETO OPEN" },
      { round: "Swiss Stage R4-R5", date: "27 Oct · 04:00 PM IST", status: "SCHEDULED" },
      { round: "Top 4 LAN Finals", date: "01 Nov · DUK Main Stage", status: "ON-CAMPUS ARENA" },
    ],
  },
  {
    title: "Algorithmic Speedcode Qualifier",
    stream: "TECH",
    prize: "₹8,000",
    regFee: "FREE",
    date: "27 OCT 2026",
    format: "CODECHEF PROCTORED ROUND",
    rounds: [
      { round: "Online Preliminary", date: "27 Oct · 08:00 PM IST", status: "PORTAL REG OPEN" },
      { round: "Finalist Hackoff", date: "31 Oct · DUK Computing Lab", status: "ON-CAMPUS STAGE" },
    ],
  },
];

document.addEventListener("DOMContentLoaded", () => {
  const container = document.getElementById("qualifiers-list");
  if (!container) return;

  container.innerHTML = qualifiers
    .map(
      (q) => `
      <div class="glass-card" style="padding: 28px; border: 1px solid var(--color-line);">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px; border-bottom: 1px solid var(--color-line); padding-bottom: 16px; margin-bottom: 20px;">
          <div>
            <span class="font-mono text-xs text-mint">${q.stream} // PRE-FEST QUALIFIER</span>
            <h3 style="font-size: 22px; font-weight: 800; color: #fff; margin-top: 4px;">${q.title}</h3>
            <p class="font-mono text-xs text-muted" style="margin-top: 4px;">PRIZE: <strong style="color: var(--color-emerald);">${q.prize}</strong> | REGISTRATION: <strong>${q.regFee}</strong></p>
          </div>
          <span class="font-mono text-xs" style="padding: 4px 10px; border-radius: 4px; border: 1px solid #2ee59d; color: #2ee59d; background: rgba(46,229,157,0.1);">
            ${q.format}
          </span>
        </div>

        <div style="display: flex; flex-direction: column; gap: 10px;">
          ${q.rounds
            .map(
              (r) => `
            <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.06); border-radius: 4px; padding: 10px 16px; font-family: var(--font-mono); font-size: 12px;">
              <div>
                <strong style="color: #fff;">${r.round}</strong>
                <span style="color: var(--color-muted); margin-left: 12px;">${r.date}</span>
              </div>
              <span style="color: var(--color-bone); font-size: 11px;">${r.status}</span>
            </div>
          `
            )
            .join("")}
        </div>
      </div>
    `
    )
    .join("");
});
