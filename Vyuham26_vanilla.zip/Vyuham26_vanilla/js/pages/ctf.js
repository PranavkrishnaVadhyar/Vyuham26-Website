/**
 * VYUHAM'26 CTF CYBER RANGE LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster, toast } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { cyberAudio } from "../lib/sound.js";

// Initialize shared components
renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

let challenges = [
  { id: "1", category: "Web", title: "Dimensional Gateway Bypass", points: 100, solves: 42, unlocked: true, solved: true, prompt: "Inspect hidden HTTP header reflections and bypass the gateway token check.", flagPattern: "gateway" },
  { id: "2", category: "Crypto", title: "Quantum Cipher Rift", points: 250, solves: 18, unlocked: true, solved: false, prompt: "Decrypt the XOR stream cipher with the repeating 16-byte cryptographic key.", flagPattern: "quantum" },
  { id: "3", category: "Reverse", title: "Doomsday Binary Injector", points: 400, solves: 7, unlocked: true, solved: false, prompt: "Disassemble the ELF binary payload and find the hardcoded comparison function.", flagPattern: "injector" },
  { id: "4", category: "Forensics", title: "Corrupted Memory Transmission", points: 500, solves: 3, unlocked: false, solved: false, prompt: "Extract the buried steganographic payload from the memory dump PCAP stream.", flagPattern: "memory" },
];

let activeChallenge = null;

document.addEventListener("DOMContentLoaded", () => {
  renderChallenges();
  setupFlagForm();
  updateSquadScore();
});

function updateSquadScore() {
  const squadScoreEl = document.getElementById("squad-score");
  if (!squadScoreEl) return;
  const score = 750 + challenges.reduce((acc, c) => (c.solved ? acc + c.points : acc), 0);
  squadScoreEl.textContent = `${score.toLocaleString()} PTS`;
}

function renderChallenges() {
  const grid = document.getElementById("challenges-grid");
  if (!grid) return;

  grid.innerHTML = challenges
    .map((ch) => {
      const isSelected = activeChallenge?.id === ch.id;
      const border = ch.solved ? "rgba(46,229,157,0.5)" : isSelected ? "var(--color-emerald)" : "var(--color-line)";
      const bg = ch.solved ? "rgba(46,229,157,0.06)" : isSelected ? "var(--color-ink-mid)" : "rgba(11,20,16,0.6)";

      return `
        <div class="glass-card" style="padding: 20px; border: 1px solid ${border}; background: ${bg}; cursor: ${ch.unlocked ? "pointer" : "not-allowed"}; opacity: ${ch.unlocked ? "1" : "0.5"}; transition: all 0.3s;" onclick="window.selectChallenge('${ch.id}')">
          <div style="display: flex; justify-content: space-between; align-items: center; font-family: var(--font-mono); font-size: 11px;">
            <span style="color: var(--color-muted);">${ch.category}</span>
            <span style="color: var(--color-emerald); font-weight: 700;">+${ch.points} PTS</span>
          </div>

          <h4 style="font-size: 16px; font-weight: 700; margin-top: 10px; color: ${ch.solved ? "var(--color-emerald)" : "#fff"};">
            ${ch.title}
          </h4>

          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; font-family: var(--font-mono); font-size: 10px;">
            <span style="color: var(--color-muted);">${ch.solves} Solves</span>
            <span style="font-weight: 700; color: ${ch.solved ? "#2ee59d" : ch.unlocked ? "#f59e0b" : "var(--color-muted)"};">
              ${ch.solved ? "✓ SOLVED" : ch.unlocked ? "● UNLOCKED" : "🔒 LOCKED"}
            </span>
          </div>
        </div>
      `;
    })
    .join("");
}

window.selectChallenge = (id) => {
  const ch = challenges.find((c) => c.id === id);
  if (!ch || !ch.unlocked) {
    if (ch && !ch.unlocked) toast("Challenge node is locked until earlier tiers are solved.", "warn");
    return;
  }

  activeChallenge = ch;
  cyberAudio.playClick();
  renderChallenges();
  renderActiveChallengeDetails();
};

function renderActiveChallengeDetails() {
  const detailsEl = document.getElementById("active-challenge-details");
  const formEl = document.getElementById("flag-submission-form");
  const statusEl = document.getElementById("flag-verification-status");
  if (!detailsEl || !formEl) return;

  if (!activeChallenge) {
    detailsEl.innerHTML = `<div style="text-align: center; padding: 40px 0; color: var(--color-muted); font-family: var(--font-mono); font-size: 12px;">Select a challenge node from the grid.</div>`;
    formEl.style.display = "none";
    return;
  }

  detailsEl.innerHTML = `
    <div>
      <span class="font-mono text-xs" style="color: var(--color-emerald);">${activeChallenge.category} // ${activeChallenge.points} PTS</span>
      <h3 style="font-size: 18px; font-weight: 700; margin-top: 4px; color: #fff;">${activeChallenge.title}</h3>
      <p style="font-family: var(--font-mono); font-size: 12px; color: var(--color-muted); margin-top: 10px; line-height: 1.6;">
        ${activeChallenge.prompt}
      </p>
    </div>
  `;

  if (activeChallenge.solved) {
    formEl.style.display = "none";
    detailsEl.innerHTML += `
      <div style="margin-top: 16px; padding: 12px; border: 1px solid #2ee59d; background: rgba(46,229,157,0.1); border-radius: 4px; text-align: center; font-family: var(--font-mono); font-size: 11px; color: #2ee59d;">
        ✓ FLAG HAS BEEN VERIFIED & REWARDED FOR THIS SQUAD
      </div>
    `;
  } else {
    formEl.style.display = "block";
    if (statusEl) statusEl.innerHTML = "";
  }
}

function setupFlagForm() {
  const form = document.getElementById("flag-submission-form");
  const input = document.getElementById("flag-input");
  const statusEl = document.getElementById("flag-verification-status");
  if (!form || !input) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!activeChallenge) return;

    const flagVal = input.value.trim().toLowerCase();
    statusEl.innerHTML = `<span style="color: #f59e0b;">VERIFYING HASH WITH ROOT KEYRING...</span>`;
    cyberAudio.playBeep(600, 0.05);

    setTimeout(() => {
      const isCorrect =
        flagVal.includes("vyuham") &&
        (flagVal.includes(activeChallenge.flagPattern) || flagVal.includes("flag") || flagVal.length > 8);

      if (isCorrect) {
        cyberAudio.playAccessGranted();
        statusEl.innerHTML = `<span style="color: #2ee59d; font-weight: 700;">✓ ACCESS GRANTED! +${activeChallenge.points} PTS ALLOCATED</span>`;
        activeChallenge.solved = true;
        challenges = challenges.map((c) => (c.id === activeChallenge.id ? { ...c, solved: true } : c));

        // Unlock next challenge if locked
        const nextLocked = challenges.find((c) => !c.unlocked);
        if (nextLocked) nextLocked.unlocked = true;

        input.value = "";
        updateSquadScore();
        renderChallenges();
        renderActiveChallengeDetails();
        toast(`Flag accepted! +${activeChallenge.points} PTS awarded to squad`, "ok");
      } else {
        cyberAudio.playAccessDenied();
        statusEl.innerHTML = `<span style="color: #ef4444;">✕ INVALID FLAG HASH. CHECKSUM MISMATCH.</span>`;
        toast("Flag validation failed. Double check decrypt key.", "error");
      }
    }, 800);
  });
}
