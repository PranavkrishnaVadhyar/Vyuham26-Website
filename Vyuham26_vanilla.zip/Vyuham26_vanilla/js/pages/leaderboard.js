/**
 * VYUHAM'26 LIVE LEADERBOARD LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster, toast } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

const teams = [
  { rank: 1, prevRank: 2, name: "CyberVipers", college: "Digital University Kerala", score: 1450, solves: 12, category: "hackathon" },
  { rank: 2, prevRank: 1, name: "ByteBusters", college: "IIT Madras", score: 1380, solves: 11, category: "hackathon" },
  { rank: 3, prevRank: 3, name: "NullPointer Squad", college: "NIT Calicut", score: 1210, solves: 10, category: "ctf" },
  { rank: 4, prevRank: 5, name: "QuantumGlitch", college: "CET Trivandrum", score: 980, solves: 8, category: "ctf" },
  { rank: 5, prevRank: 4, name: "BinaryKnights", college: "CUSAT", score: 920, solves: 7, category: "hackathon" },
  { rank: 6, prevRank: 6, name: "Protocol X", college: "TKM College of Engineering", score: 860, solves: 6, category: "ctf" },
];

let currentFilter = "all";

document.addEventListener("DOMContentLoaded", () => {
  renderLeaderboard();
  setupFilterButtons();
});

function setupFilterButtons() {
  const btnAll = document.getElementById("btn-filter-all");
  const btnHack = document.getElementById("btn-filter-hackathon");
  const btnCtf = document.getElementById("btn-filter-ctf");

  const setActive = (activeBtn, cat) => {
    [btnAll, btnHack, btnCtf].forEach((b) => {
      b.className = "btn btn-outline";
      b.style.padding = "6px 14px";
      b.style.fontSize = "11px";
    });
    activeBtn.className = "btn btn-primary";
    currentFilter = cat;
    renderLeaderboard();
  };

  if (btnAll) btnAll.addEventListener("click", () => setActive(btnAll, "all"));
  if (btnHack) btnHack.addEventListener("click", () => setActive(btnHack, "hackathon"));
  if (btnCtf) btnCtf.addEventListener("click", () => setActive(btnCtf, "ctf"));
}

function renderLeaderboard() {
  const stack = document.getElementById("leaderboard-stack");
  if (!stack) return;

  const filtered = teams.filter((t) => currentFilter === "all" || t.category === currentFilter);

  stack.innerHTML = filtered
    .map((team) => {
      const delta = team.prevRank - team.rank;
      const isFirst = team.rank === 1;
      const border = isFirst ? "var(--color-emerald)" : "var(--color-line)";
      const bg = isFirst ? "rgba(46,229,157,0.08)" : "rgba(11,20,16,0.6)";

      const badgeBg =
        team.rank === 1
          ? "var(--color-emerald)"
          : team.rank === 2
          ? "#ffffff"
          : team.rank === 3
          ? "#f59e0b"
          : "rgba(255,255,255,0.1)";
      const badgeColor = team.rank <= 3 ? "#000" : "#fff";

      return `
        <div class="glass-card" style="padding: 20px; border: 1px solid ${border}; background: ${bg}; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; transition: all 0.3s;">
          <div style="display: flex; align-items: center; gap: 20px;">
            <div style="width: 44px; height: 44px; border-radius: 50%; background: ${badgeBg}; color: ${badgeColor}; display: flex; align-items: center; justify-content: center; font-family: var(--font-mono); font-size: 16px; font-weight: 800;">
              #${team.rank}
            </div>
            <div>
              <div style="display: flex; align-items: center; gap: 10px;">
                <h3 style="font-size: 18px; font-weight: 700; color: #fff;">${team.name}</h3>
                ${
                  delta > 0
                    ? `<span class="font-mono text-xs text-mint">▲ +${delta}</span>`
                    : delta < 0
                    ? `<span class="font-mono text-xs" style="color: #ef4444;">▼ ${delta}</span>`
                    : ""
                }
              </div>
              <p class="font-mono text-xs text-muted" style="margin-top: 2px;">${team.college}</p>
            </div>
          </div>

          <div style="text-align: right; font-family: var(--font-mono);">
            <div style="font-size: 20px; font-weight: 800; color: var(--color-emerald);">${team.score.toLocaleString()} PTS</div>
            <div style="font-size: 11px; color: var(--color-muted); margin-top: 2px;">${team.solves} CHALLENGES SOLVED</div>
          </div>
        </div>
      `;
    })
    .join("");
}
