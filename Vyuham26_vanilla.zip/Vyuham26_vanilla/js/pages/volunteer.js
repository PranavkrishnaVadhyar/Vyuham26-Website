/**
 * VYUHAM'26 VOLUNTEER STATION SCANNER LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster, toast } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { authState } from "../lib/auth.js";
import { checkinApi } from "../lib/api.js";
import { cyberAudio } from "../lib/sound.js";

let currentStation = localStorage.getItem("vyuham26:volunteer_station") || "Gate 1 - Main Entrance";
let cameraStream = null;
let facingMode = "environment";
let isScanning = false;
let scanLoopId = null;
let rapidMode = false;
let historyRecords = [];

// Initialize shared components
renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

document.addEventListener("DOMContentLoaded", () => {
  setupStationSelect();
  setupCameraControls();
  setupManualForm();
  setupHistoryTable();
  updateOperatorBadge();
  loadHistory();
});

function updateOperatorBadge() {
  const user = authState.getUser();
  const operatorBadge = document.getElementById("operator-badge");
  if (operatorBadge) {
    operatorBadge.textContent = (user?.name || user?.email || "VOLUNTEER #402").toUpperCase();
  }
}

function setupStationSelect() {
  const select = document.getElementById("station-select");
  if (!select) return;
  select.value = currentStation;
  select.addEventListener("change", (e) => {
    currentStation = e.target.value;
    localStorage.setItem("vyuham26:volunteer_station", currentStation);
    toast(`Station shifted to: ${currentStation}`, "info");
    loadHistory();
  });
}

function setupCameraControls() {
  const toggleBtn = document.getElementById("toggle-camera-btn");
  const flipBtn = document.getElementById("flip-camera-btn");
  const rapidToggle = document.getElementById("rapid-mode-toggle");

  if (rapidToggle) {
    rapidToggle.addEventListener("change", (e) => {
      rapidMode = e.target.checked;
      toast(rapidMode ? "Rapid stream mode enabled" : "Rapid mode disabled", "info");
    });
  }

  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      if (isScanning) {
        stopCamera();
      } else {
        startCamera();
      }
    });
  }

  if (flipBtn) {
    flipBtn.addEventListener("click", () => {
      facingMode = facingMode === "environment" ? "user" : "environment";
      if (isScanning) {
        stopCamera();
        startCamera();
      }
    });
  }
}

async function startCamera() {
  const video = document.getElementById("scanner-video");
  const placeholder = document.getElementById("camera-placeholder");
  const toggleBtn = document.getElementById("toggle-camera-btn");
  const statusSpan = document.getElementById("scan-feedback-status");

  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      toast("Camera API not supported in this browser.", "error");
      return;
    }

    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: facingMode }, width: { ideal: 1280 }, height: { ideal: 720 } },
    });

    if (video) {
      video.srcObject = cameraStream;
      video.setAttribute("playsinline", "true");
      await video.play();
    }

    if (placeholder) placeholder.style.display = "none";
    if (toggleBtn) toggleBtn.textContent = "STOP CAMERA";
    if (statusSpan) statusSpan.textContent = "OPTICAL RADAR ACTIVE";
    isScanning = true;

    startBarcodeDetection(video);
  } catch (err) {
    toast(`Camera error: ${err.message || "Permission denied"}`, "error");
    stopCamera();
  }
}

function stopCamera() {
  const video = document.getElementById("scanner-video");
  const placeholder = document.getElementById("camera-placeholder");
  const toggleBtn = document.getElementById("toggle-camera-btn");
  const statusSpan = document.getElementById("scan-feedback-status");

  if (scanLoopId) {
    cancelAnimationFrame(scanLoopId);
    scanLoopId = null;
  }

  if (cameraStream) {
    cameraStream.getTracks().forEach((t) => t.stop());
    cameraStream = null;
  }

  if (video) {
    video.srcObject = null;
  }

  if (placeholder) placeholder.style.display = "block";
  if (toggleBtn) toggleBtn.textContent = "START CAMERA";
  if (statusSpan) statusSpan.textContent = "STANDBY";
  isScanning = false;
}

function startBarcodeDetection(video) {
  if (typeof window.BarcodeDetector === "function") {
    const detector = new window.BarcodeDetector({ formats: ["qr_code", "code_128", "code_39"] });
    let lastCode = "";
    let lastTime = 0;

    const loop = async () => {
      if (video && video.readyState === video.HAVE_ENOUGH_DATA) {
        try {
          const codes = await detector.detect(video);
          if (codes && codes.length > 0) {
            const val = codes[0].rawValue;
            const now = Date.now();
            if (val && (val !== lastCode || now - lastTime > 3000)) {
              lastCode = val;
              lastTime = now;
              handleProcessScan(val);
            }
          }
        } catch (e) {}
      }
      if (isScanning) {
        scanLoopId = requestAnimationFrame(loop);
      }
    };
    scanLoopId = requestAnimationFrame(loop);
  } else {
    // Canvas frame snapshot fallback simulation or notice
    const statusSpan = document.getElementById("scan-feedback-status");
    if (statusSpan) statusSpan.textContent = "CAMERA LIVE (BARCODE API EMULATED)";
  }
}

function setupManualForm() {
  const form = document.getElementById("manual-scan-form");
  const input = document.getElementById("manual-code-input");
  if (!form || !input) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const val = input.value.trim();
    if (!val) return;
    handleProcessScan(val);
    input.value = "";
  });
}

async function handleProcessScan(rawCode) {
  const code = rawCode.trim().toUpperCase();
  if (!code) return;

  const user = authState.getUser();
  const operatorName = user?.name || user?.email || "VOLUNTEER";

  try {
    const res = await checkinApi.scanPass({
      ticket_code: code,
      station: currentStation,
      volunteer_name: operatorName,
    });

    cyberAudio.playScanSound(res.status);
    displayVerdict(res);

    if (res.status === "approved") {
      toast(`[APPROVED] ${res.attendee_name || "OPERATIVE"} admitted at ${currentStation}`, "ok");
    } else if (res.status === "duplicate") {
      toast(`[DUPLICATE] Pass ${code} already admitted at ${currentStation}`, "error");
    } else {
      toast(`[INVALID] Pass ${code} not verified in festival registry`, "error");
    }

    loadHistory();

    if (rapidMode) {
      setTimeout(() => {
        const container = document.getElementById("verdict-details-container");
        const pill = document.getElementById("verdict-status-pill");
        if (container) {
          container.innerHTML = `<div style="text-align: center; padding: 48px 0; color: var(--color-muted); font-family: var(--font-mono); font-size: 13px;">Ready for next attendee scan...</div>`;
        }
        if (pill) {
          pill.className = "font-mono text-xs";
          pill.style.background = "rgba(255,255,255,0.05)";
          pill.style.color = "var(--color-muted)";
          pill.textContent = "READY FOR SCAN";
        }
      }, 2500);
    }
  } catch (err) {
    cyberAudio.playScanSound("invalid");
    toast(`Scan error: ${err.message || "Failed to reach gate server"}`, "error");
  }
}

function displayVerdict(res) {
  const container = document.getElementById("verdict-details-container");
  const pill = document.getElementById("verdict-status-pill");
  if (!container || !pill) return;

  const isApproved = res.status === "approved";
  const isDuplicate = res.status === "duplicate";
  const badgeClass = isApproved ? "badge-approved" : isDuplicate ? "badge-duplicate" : "badge-invalid";
  const badgeText = isApproved ? "✓ ACCESS APPROVED" : isDuplicate ? "⚠️ DUPLICATE TICKET" : "⛔ INVALID PASS";

  pill.className = `font-mono text-xs ${badgeClass}`;
  pill.textContent = res.status.toUpperCase();

  container.innerHTML = `
    <div style="border-radius: 8px; padding: 24px; border: 1px solid ${isApproved ? "#2ee59d" : isDuplicate ? "#f59e0b" : "#ef4444"}; background: ${isApproved ? "rgba(46,229,157,0.08)" : isDuplicate ? "rgba(245,158,11,0.08)" : "rgba(239,68,68,0.08)"};">
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed rgba(255,255,255,0.15); padding-bottom: 12px; margin-bottom: 16px;">
        <span class="font-mono text-xs font-bold" style="color: ${isApproved ? "#2ee59d" : isDuplicate ? "#f59e0b" : "#ef4444"};">${badgeText}</span>
        <span class="font-mono text-xs text-muted">${res.scanned_at || "JUST NOW"}</span>
      </div>

      <div class="font-mono" style="font-size: 13px; line-height: 1.8;">
        <div>TICKET CODE: <strong style="color: #fff;">${res.ticket_code}</strong></div>
        <div>ATTENDEE: <strong style="color: #2ee59d; font-size: 15px;">${res.attendee_name || "UNKNOWN"}</strong></div>
        <div>INSTITUTION: <strong>${res.college || "Digital University Kerala"}</strong></div>
        <div>EVENT PASS: <strong>${res.event_name || "VYUHAM'26 MAIN ADMISSION"}</strong></div>
        <div>STATION: <strong>${res.station || currentStation}</strong></div>
        ${res.notes ? `<div style="margin-top: 8px; color: #f59e0b; font-size: 11px;">NOTE: ${res.notes}</div>` : ""}
      </div>
    </div>
  `;
}

function setupHistoryTable() {
  const searchInput = document.getElementById("log-search-input");
  const filterSelect = document.getElementById("log-filter-status");
  const refreshBtn = document.getElementById("refresh-history-btn");
  const clearBtn = document.getElementById("clear-local-history-btn");

  if (searchInput) searchInput.addEventListener("input", renderHistoryTable);
  if (filterSelect) filterSelect.addEventListener("change", renderHistoryTable);
  if (refreshBtn) refreshBtn.addEventListener("click", () => { loadHistory(); toast("Station log refreshed", "info"); });
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      if (confirm("Clear local station check-in cache?")) {
        localStorage.removeItem("vyuham26:live_checkins:v1");
        loadHistory();
        toast("Local check-in history cleared", "info");
      }
    });
  }
}

async function loadHistory() {
  try {
    const list = await checkinApi.getHistory(currentStation);
    historyRecords = Array.isArray(list) ? list : [];
    renderHistoryTable();
  } catch (err) {
    historyRecords = [];
    renderHistoryTable();
  }
}

function renderHistoryTable() {
  const tbody = document.getElementById("history-table-body");
  const searchInput = document.getElementById("log-search-input");
  const filterSelect = document.getElementById("log-filter-status");
  if (!tbody) return;

  const query = (searchInput?.value || "").toLowerCase().trim();
  const filter = filterSelect?.value || "all";

  const filtered = historyRecords.filter((rec) => {
    const matchesFilter = filter === "all" || rec.status === filter;
    const matchesQuery =
      !query ||
      (rec.ticket_code && rec.ticket_code.toLowerCase().includes(query)) ||
      (rec.attendee_name && rec.attendee_name.toLowerCase().includes(query));
    return matchesFilter && matchesQuery;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="padding: 24px; text-align: center; color: var(--color-muted);">No records match the current filter.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered
    .map((rec) => {
      const isApproved = rec.status === "approved";
      const isDuplicate = rec.status === "duplicate";
      const color = isApproved ? "#2ee59d" : isDuplicate ? "#f59e0b" : "#ef4444";
      return `
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); transition: background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.03)'" onmouseout="this.style.background='transparent'">
          <td style="padding: 10px; color: var(--color-muted);">${rec.scanned_at || "—"}</td>
          <td style="padding: 10px; font-weight: 700; color: #fff;">${rec.ticket_code}</td>
          <td style="padding: 10px; color: #fff;">${rec.attendee_name || "—"}</td>
          <td style="padding: 10px; color: var(--color-muted);">${rec.college || "Digital University Kerala"}</td>
          <td style="padding: 10px; color: var(--color-muted);">${rec.event_name || "FESTIVAL PASS"}</td>
          <td style="padding: 10px;">
            <span style="display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 700; border: 1px solid ${color}; color: ${color};">
              ${(rec.status || "UNKNOWN").toUpperCase()}
            </span>
          </td>
        </tr>
      `;
    })
    .join("");
}
