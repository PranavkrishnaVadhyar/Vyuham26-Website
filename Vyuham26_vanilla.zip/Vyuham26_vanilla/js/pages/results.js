/**
 * VYUHAM'26 RESULTS LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { adminApi } from "../lib/api.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

const defaultResults = [
  {
    event: "Hackathon — 24HR",
    stream: "TECH",
    prize: "₹30,000",
    first: "CyberVipers (Digital University Kerala)",
    second: "ByteBusters (IIT Madras)",
    third: "NullPointer Squad (NIT Calicut)",
    publishedAt: "01 NOV 2026",
  },
  {
    event: "Capture The Flag",
    stream: "TECH",
    prize: "₹15,000",
    first: "QuantumGlitch (CET Trivandrum)",
    second: "CyberVipers (Digital University Kerala)",
    third: "BinaryKnights (CUSAT)",
    publishedAt: "31 OCT 2026",
  },
  {
    event: "Best Manager",
    stream: "MANAGEMENT",
    prize: "₹15,000",
    first: "Aarav Sharma (IIM Kozhikode)",
    second: "Ananya Pillai (SCMS Cochin)",
    third: "Kavya Menon (Rajagiri Centre)",
    publishedAt: "30 OCT 2026",
  },
  {
    event: "Valorant Tournament",
    stream: "ESPORTS",
    prize: "₹10,000",
    first: "Void Strikers",
    second: "Apex Protocol",
    third: "Phantom Vanguard",
    publishedAt: "01 NOV 2026",
  },
  {
    event: "Prompt War",
    stream: "TECH",
    prize: "₹8,000",
    first: "Rohan Thomas",
    second: "Nithya Das",
    third: "Alen Joseph",
    publishedAt: "31 OCT 2026",
  },
  {
    event: "Battle of the Bands",
    stream: "CULTURAL",
    prize: "₹25,000",
    first: "Echo Horizon",
    second: "The Velvet Static",
    third: "Neon Pulse",
    publishedAt: "01 NOV 2026",
  },
];

document.addEventListener("DOMContentLoaded", async () => {
  const grid = document.getElementById("results-grid");
  if (!grid) return;

  let results = defaultResults;
  try {
    const apiRes = await adminApi.getResults();
    if (Array.isArray(apiRes) && apiRes.length > 0) {
      results = apiRes.map((r) => ({
        event: r.event_name,
        stream: (r.stream || "TECH").toUpperCase(),
        prize: r.prize_distributed || "₹10,000",
        first: r.first_place,
        second: r.second_place,
        third: r.third_place || "TBA",
        publishedAt: r.published_at || "01 NOV 2026",
      }));
    }
  } catch (e) {}

  grid.innerHTML = results
    .map(
      (res) => `
      <div class="glass-card" style="padding: 24px; border: 1px solid var(--color-line); display: flex; flex-direction: column; justify-content: space-between;">
        <div>
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--color-line); padding-bottom: 12px; margin-bottom: 16px;">
            <span class="font-mono text-xs text-mint">${res.stream} // CERTIFIED</span>
            <span class="font-mono text-xs" style="color: var(--color-emerald); font-weight: 700;">PRIZE POOL: ${res.prize}</span>
          </div>

          <h3 style="font-size: 20px; font-weight: 800; color: #fff;">${res.event}</h3>

          <div style="margin-top: 16px; display: flex; flex-direction: column; gap: 10px; font-family: var(--font-mono); font-size: 13px;">
            <div style="display: flex; align-items: center; gap: 10px; background: rgba(46,229,157,0.08); border: 1px solid rgba(46,229,157,0.3); border-radius: 4px; padding: 10px 14px;">
              <span style="color: #2ee59d; font-weight: 800;">🥇 1ST:</span>
              <strong style="color: #fff;">${res.first}</strong>
            </div>

            <div style="display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); border-radius: 4px; padding: 8px 14px;">
              <span style="color: #ffffff; font-weight: 800;">🥈 2ND:</span>
              <span style="color: var(--color-bone);">${res.second}</span>
            </div>

            <div style="display: flex; align-items: center; gap: 10px; background: rgba(245,158,11,0.03); border: 1px solid rgba(245,158,11,0.15); border-radius: 4px; padding: 8px 14px;">
              <span style="color: #f59e0b; font-weight: 800;">🥉 3RD:</span>
              <span style="color: var(--color-bone);">${res.third}</span>
            </div>
          </div>
        </div>

        <div style="border-top: 1px dashed rgba(255,255,255,0.1); padding-top: 14px; margin-top: 20px; display: flex; justify-content: space-between; font-family: var(--font-mono); font-size: 11px; color: var(--color-muted);">
          <span>PUBLISHED: ${res.publishedAt}</span>
          <span style="color: var(--color-emerald);">AUTHENTICATED BY JURY</span>
        </div>
      </div>
    `
    )
    .join("");
});
