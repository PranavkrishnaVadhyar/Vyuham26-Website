/**
 * VYUHAM'26 FOOD COURT & DIGITAL WALLET LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster, toast } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { cyberAudio } from "../lib/sound.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

const STORAGE_KEY = "vyuham26:food_wallet_balance";

function getWalletBalance() {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw !== null ? parseInt(raw, 10) : 450;
}

function setWalletBalance(bal) {
  localStorage.setItem(STORAGE_KEY, String(bal));
}

const vendors = [
  { name: "DUK Central Refreshments", category: "Snacks & Beverages", status: "OPEN", location: "Main Zone A", stallNo: "02" },
  { name: "Cyber Cyber Café", category: "Coffee & Artisanal Burgers", status: "OPEN", location: "Technocity Hub", stallNo: "01" },
  { name: "Malabar Spice Express", category: "Kerala Meals & Biryani", status: "OPEN", location: "Food Court Stall 03", stallNo: "03" },
  { name: "Wok & Roll Noodles", category: "Asian Street Food", status: "CLOSING SOON", location: "Food Court Stall 04", stallNo: "04" },
];

document.addEventListener("DOMContentLoaded", () => {
  renderVendorsGrid();
  setupWalletPage();
  setupTopupPage();
  setupVendorPage();
});

function renderVendorsGrid() {
  const grid = document.getElementById("food-vendors-grid");
  const balanceBtn = document.getElementById("wallet-balance-btn");
  if (balanceBtn) {
    balanceBtn.textContent = `MY WALLET (₹${getWalletBalance()})`;
  }
  if (!grid) return;

  grid.innerHTML = vendors
    .map(
      (vendor) => `
      <div class="glass-card" style="padding: 24px; border: 1px solid var(--color-line); display: flex; flex-direction: column; justify-content: space-between; transition: all 0.3s;">
        <div>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span class="font-mono text-xs text-muted">STALL ${vendor.stallNo} // ${vendor.category}</span>
            <span class="font-mono text-xs" style="padding: 2px 8px; border-radius: 4px; border: 1px solid ${vendor.status === "OPEN" ? "#2ee59d" : "#f59e0b"}; color: ${vendor.status === "OPEN" ? "#2ee59d" : "#f59e0b"}; background: ${vendor.status === "OPEN" ? "rgba(46,229,157,0.1)" : "rgba(245,158,11,0.1)"};">
              ● ${vendor.status}
            </span>
          </div>

          <h3 style="font-size: 20px; font-weight: 800; color: #fff; margin-top: 12px;">${vendor.name}</h3>
          <p class="font-mono text-xs text-muted" style="margin-top: 4px;">LOCATION: <strong style="color: var(--color-bone);">${vendor.location}</strong></p>
        </div>

        <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid var(--color-line); display: flex; justify-content: space-between; align-items: center;">
          <span class="font-mono text-xs text-mint">ACCEPTS WALLET PASS</span>
          <a href="/food/vendor.html" class="btn btn-outline" style="padding: 6px 14px; font-size: 11px;">REDEEM HERE →</a>
        </div>
      </div>
    `
    )
    .join("");
}

function setupWalletPage() {
  const balDisplay = document.getElementById("wallet-balance-display");
  const gaugeFill = document.getElementById("wallet-gauge-fill");
  if (!balDisplay) return;

  const current = getWalletBalance();
  balDisplay.textContent = `₹${current}`;
  if (gaugeFill) {
    const pct = Math.min(100, Math.round((current / 1000) * 100));
    gaugeFill.style.width = `${pct}%`;
  }
}

function setupTopupPage() {
  const packBtns = document.querySelectorAll(".topup-pack-btn");
  const curBalEl = document.getElementById("topup-current-balance");
  const packSelEl = document.getElementById("topup-pack-selected");
  const newBalEl = document.getElementById("topup-new-balance");
  const proceedBtn = document.getElementById("btn-proceed-recharge");

  if (!packBtns.length) return;

  let selectedAmount = 300;
  const current = getWalletBalance();

  const update = () => {
    if (curBalEl) curBalEl.textContent = `₹${current}`;
    if (packSelEl) packSelEl.textContent = `₹${selectedAmount}`;
    if (newBalEl) newBalEl.textContent = `₹${current + selectedAmount}`;
  };
  update();

  packBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      selectedAmount = parseInt(btn.getAttribute("data-amount"), 10);
      cyberAudio.playClick();
      packBtns.forEach((b) => (b.className = "btn btn-outline topup-pack-btn"));
      btn.className = "btn btn-primary topup-pack-btn";
      update();
    });
  });

  if (proceedBtn) {
    proceedBtn.addEventListener("click", () => {
      cyberAudio.playBeep(600, 0.08);
      const newTotal = current + selectedAmount;
      setWalletBalance(newTotal);
      cyberAudio.playAccessGranted();
      toast(`Successfully recharged +₹${selectedAmount}! New Balance: ₹${newTotal}`, "ok");
      setTimeout(() => {
        window.location.href = "/food/wallet.html";
      }, 1200);
    });
  }
}

function setupVendorPage() {
  const form = document.getElementById("vendor-redeem-form");
  const amountInput = document.getElementById("vendor-debit-amount");
  const passInput = document.getElementById("vendor-pass-code");
  const stallSelect = document.getElementById("vendor-stall-select");
  const resultBox = document.getElementById("vendor-result-box");

  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const debit = parseInt(amountInput?.value || "0", 10);
    const pass = passInput?.value.trim();
    const stall = stallSelect?.value;
    const current = getWalletBalance();

    if (debit <= 0) {
      toast("Invalid debit amount", "warn");
      return;
    }

    if (debit > current) {
      cyberAudio.playAccessDenied();
      resultBox.style.display = "block";
      resultBox.style.background = "rgba(239,68,68,0.15)";
      resultBox.style.border = "1px solid #ef4444";
      resultBox.innerHTML = `
        <h3 style="color: #ef4444; font-size: 20px; font-weight: 800;">✕ INSUFFICIENT BALANCE</h3>
        <p class="font-mono text-xs" style="color: #fff; margin-top: 6px;">Requested: ₹${debit} | Available: ₹${current}</p>
        <p class="font-mono text-xs text-muted" style="margin-top: 4px;">Ask attendee to top up wallet before re-authorizing.</p>
      `;
      toast("Transaction declined: Insufficient balance", "error");
      return;
    }

    // Deduct
    const newBal = current - debit;
    setWalletBalance(newBal);
    cyberAudio.playAccessGranted();

    resultBox.style.display = "block";
    resultBox.style.background = "rgba(46,229,157,0.15)";
    resultBox.style.border = "1px solid #2ee59d";
    resultBox.innerHTML = `
      <h3 style="color: #2ee59d; font-size: 20px; font-weight: 800;">✓ DEBIT AUTHORIZED</h3>
      <p class="font-mono text-xs" style="color: #fff; margin-top: 6px;">₹${debit} debited from pass ${pass} at ${stall}</p>
      <p class="font-mono text-xs text-mint" style="margin-top: 4px;">Remaining Attendee Balance: ₹${newBal}</p>
    `;
    toast(`Payment of ₹${debit} approved!`, "ok");
  });
}
