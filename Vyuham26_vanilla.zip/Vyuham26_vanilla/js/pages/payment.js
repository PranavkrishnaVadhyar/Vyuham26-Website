/**
 * VYUHAM'26 COMMERCE PAYMENT & RECEIPT CONTROLLER
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster, toast } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { authState } from "../lib/auth.js";
import { paymentsApi } from "../lib/api.js";
import { cyberAudio } from "../lib/sound.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

document.addEventListener("DOMContentLoaded", () => {
  setupPaymentPage();
  setupReceiptPage();
  setupConfirmationPage();
});

function setupPaymentPage() {
  const form = document.getElementById("payment-action-form");
  const totalDisplay = document.getElementById("payment-total-display");
  const txnRefDisplay = document.getElementById("payment-txn-ref");
  const methodBtns = document.querySelectorAll(".pay-method-btn");

  if (!form) return;

  const urlParams = new URLSearchParams(window.location.search);
  const amountFromUrl = urlParams.get("amount");
  if (amountFromUrl && totalDisplay) {
    totalDisplay.textContent = `₹${amountFromUrl}`;
  }

  const txnRef = `TXN-VYU-${Math.floor(100000 + Math.random() * 900000)}`;
  if (txnRefDisplay) txnRefDisplay.textContent = txnRef;

  methodBtns.forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      cyberAudio.playClick();
      methodBtns.forEach((b) => (b.className = "btn btn-outline pay-method-btn"));
      btn.className = "btn btn-primary pay-method-btn";
    });
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    cyberAudio.playBeep(880, 0.08);
    const payBtn = document.getElementById("btn-pay-now");
    if (payBtn) {
      payBtn.textContent = "VERIFYING ENCRYPTED SETTLEMENT...";
      payBtn.disabled = true;
    }

    try {
      await paymentsApi.verifyPayment(txnRef);
    } catch (err) {}

    cyberAudio.playAccessGranted();
    toast("Payment verified successfully!", "ok");
    setTimeout(() => {
      window.location.href = `/confirmation?ref=${encodeURIComponent(txnRef)}`;
    }, 1000);
  });
}

async function setupReceiptPage() {
  const txnRefEl = document.getElementById("receipt-txn-ref");
  const receiptNoEl = document.getElementById("receipt-no-display");
  const dateEl = document.getElementById("receipt-date-display");
  const attendeeEl = document.getElementById("receipt-attendee-name");
  const totalEl = document.getElementById("receipt-total-display");

  if (!receiptNoEl) return;

  const urlParams = new URLSearchParams(window.location.search);
  const ref = urlParams.get("ref") || `TXN-VYU-${Math.floor(100000 + Math.random() * 900000)}`;

  try {
    const data = await paymentsApi.getReceipt(ref);
    if (txnRefEl) txnRefEl.textContent = ref;
    if (receiptNoEl) receiptNoEl.textContent = `RECEIPT #${data.receipt_no || "REC-2026-84920"}`;
    if (dateEl) dateEl.textContent = data.timestamp || "30 OCT 2026, 10:14 IST";
    if (totalEl) totalEl.textContent = `₹${data.total_amount || 1130}`;

    const user = authState.getUser();
    if (attendeeEl) attendeeEl.textContent = (user?.name || data.attendee_name || "AROMAL S S").toUpperCase();
  } catch (e) {}
}

function setupConfirmationPage() {
  const codeEl = document.getElementById("confirm-ticket-code");
  const attendeeEl = document.getElementById("confirm-attendee-name");
  if (!codeEl) return;

  const user = authState.getUser();
  if (attendeeEl && user?.name) {
    attendeeEl.textContent = user.name.toUpperCase();
  }
}
