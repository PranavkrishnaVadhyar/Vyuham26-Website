/**
 * VYUHAM'26 PHOTOGRAPHY CONTEST LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster, toast } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { cyberAudio } from "../lib/sound.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

let entries = [
  { id: "1", title: "Midnight Laser Core", photographer: "Aromal S.", votes: 142, voted: false, gradient: "linear-gradient(135deg, rgba(46,229,157,0.3), #030504)" },
  { id: "2", title: "Technocity Horizon", photographer: "Sneha R.", votes: 98, voted: false, gradient: "linear-gradient(135deg, rgba(168,85,247,0.3), #030504)" },
  { id: "3", title: "Crowd Surge Ignition", photographer: "Dev K.", votes: 210, voted: false, gradient: "linear-gradient(135deg, rgba(245,158,11,0.3), #030504)" },
  { id: "4", title: "Multiverse Stage Lights", photographer: "Meera P.", votes: 165, voted: false, gradient: "linear-gradient(135deg, rgba(6,182,212,0.3), #030504)" },
];

document.addEventListener("DOMContentLoaded", () => {
  renderEntries();
});

function renderEntries() {
  const grid = document.getElementById("photo-entries-grid");
  if (!grid) return;

  grid.innerHTML = entries
    .map(
      (entry) => `
      <div class="glass-card" style="padding: 24px; border: 1px solid ${entry.voted ? "var(--color-emerald)" : "var(--color-line)"}; background: ${entry.gradient}; display: flex; flex-direction: column; justify-content: space-between; min-height: 280px; transition: all 0.3s;">
        <div>
          <div style="display: flex; justify-content: space-between; align-items: center; font-family: var(--font-mono); font-size: 11px;">
            <span class="text-muted">CURATED ENTRY #${entry.id}</span>
            <span style="color: ${entry.voted ? "#2ee59d" : "#fff"}; font-weight: 700;">${entry.votes} VOTES</span>
          </div>

          <h3 style="font-size: 24px; font-weight: 800; color: #fff; margin-top: 40px;">
            ${entry.title}
          </h3>
          <p class="font-mono text-xs text-muted" style="margin-top: 4px;">Captured by: <strong style="color: var(--color-bone);">${entry.photographer}</strong></p>
        </div>

        <div style="margin-top: 32px; display: flex; justify-content: space-between; align-items: center;">
          <span class="font-mono text-xs" style="color: var(--color-emerald);">${entry.voted ? "✓ VOTE RECORDED" : "OPEN FOR VOTE"}</span>
          <button class="btn ${entry.voted ? "btn-primary" : "btn-outline"}" style="padding: 8px 16px; font-size: 11px;" onclick="window.votePhoto('${entry.id}')">
            ${entry.voted ? "VOTED ★" : "CAST VOTE ★"}
          </button>
        </div>
      </div>
    `
    )
    .join("");
}

window.votePhoto = (id) => {
  entries = entries.map((e) => {
    if (e.id === id) {
      const isNowVoted = !e.voted;
      return { ...e, voted: isNowVoted, votes: e.votes + (isNowVoted ? 1 : -1) };
    }
    return e;
  });

  cyberAudio.playClick();
  const picked = entries.find((e) => e.id === id);
  if (picked?.voted) {
    cyberAudio.playAccessGranted();
    toast(`Vote recorded for "${picked.title}"!`, "ok");
  } else {
    toast(`Vote removed for "${picked?.title}"`, "info");
  }

  renderEntries();
};
