/**
 * VYUHAM'26 FEEDBACK DEBRIEF LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster, toast } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { auxiliaryApi } from "../lib/api.js";
import { cyberAudio } from "../lib/sound.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

let selectedRating = 5;

document.addEventListener("DOMContentLoaded", () => {
  setupRatingButtons();
  setupFeedbackForm();
});

function setupRatingButtons() {
  const btns = document.querySelectorAll(".star-btn");
  btns.forEach((btn) => {
    btn.addEventListener("click", () => {
      selectedRating = parseInt(btn.getAttribute("data-rating"), 10);
      cyberAudio.playClick();
      btns.forEach((b) => {
        b.className = "btn btn-outline star-btn";
      });
      btn.className = "btn btn-primary star-btn";
    });
  });
}

function setupFeedbackForm() {
  const form = document.getElementById("feedback-form");
  const comments = document.getElementById("feedback-comments");
  const eventSelect = document.getElementById("favorite-event-select");
  const successBox = document.getElementById("feedback-success");

  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    cyberAudio.playBeep(880, 0.08);

    try {
      await auxiliaryApi.submitFeedback({
        rating: selectedRating,
        favorite_event: eventSelect?.value,
        comments: comments?.value || "",
      });
    } catch (err) {}

    cyberAudio.playAccessGranted();
    toast("Thank you for your debrief submission!", "ok");
    form.style.display = "none";
    if (successBox) successBox.style.display = "block";
  });
}
