/**
 * VYUHAM'26 FAQ ACCORDION LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { cyberAudio } from "../lib/sound.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

const faqs = [
  {
    question: "What is Vyuham 26?",
    answer: "Vyuham 26 is Digital University Kerala's national-level techno-cultural fest. It spans three full days of competitions, pro-shows, tech hackathons, esports, and cultural exhibitions across four distinct streams: Technology, Culture, Gaming, and Management.",
  },
  {
    question: "When and where does Vyuham 26 take place?",
    answer: "Vyuham 26 runs from October 30 to November 1, 2026, at the lush Technocity campus of Digital University Kerala in Thiruvananthapuram, Kerala.",
  },
  {
    question: "Who can participate?",
    answer: "Vyuham 26 is open to undergraduate, postgraduate, and research scholars from accredited universities and colleges across India. Valid college identity cards or festival digital gate passes are required for entry.",
  },
  {
    question: "How do I register for events?",
    answer: "You can create an account on this portal, browse through the Events catalog, select individual or team events, and proceed through checkout. You will immediately receive a cryptographically signed Digital Gate Pass.",
  },
  {
    question: "Is there a registration fee?",
    answer: "Festival general gate access requires a nominal registration pass. Premium competitive arenas (such as the 24HR Hackathon or Valorant LAN) have team slots with pooled prize distributions.",
  },
  {
    question: "Can I participate in multiple events?",
    answer: "Yes! You can participate in multiple events as long as the competition slots do not have scheduling conflicts. The Schedule timeline page will assist you in mapping out your three days.",
  },
  {
    question: "Is accommodation available for outstation teams?",
    answer: "Yes, dedicated hostel and partner hotel accommodation will be available near Technocity. Details and booking assistance will be provided upon successful registration.",
  },
  {
    question: "How does the digital food wallet pass work?",
    answer: "All campus food stalls at the Technocity food court accept contactless digital coupon passes. You can top-up your wallet directly through our Food Court portal.",
  },
  {
    question: "Will participation certificates be issued?",
    answer: "Yes, all verified attendees and competitors will receive cryptographically signed digital certificates issued by Digital University Kerala, accessible via our Certificates Vault.",
  },
];

document.addEventListener("DOMContentLoaded", () => {
  renderFaqAccordion();
});

function renderFaqAccordion() {
  const container = document.getElementById("faq-accordion");
  if (!container) return;

  container.innerHTML = faqs
    .map(
      (item, idx) => `
      <div class="glass-card" style="border: 1px solid var(--color-line); overflow: hidden; transition: border-color 0.3s;" id="faq-item-${idx}">
        <div style="padding: 20px 24px; cursor: pointer; display: flex; justify-content: space-between; align-items: center; user-select: none;" onclick="window.toggleFaq(${idx})">
          <h3 style="font-size: 16px; font-weight: 700; color: #fff; margin: 0;">${item.question}</h3>
          <span style="font-family: var(--font-mono); font-size: 18px; color: var(--color-emerald); transition: transform 0.3s;" id="faq-icon-${idx}">+</span>
        </div>
        <div style="display: none; padding: 0 24px 20px 24px; color: var(--color-bone); font-size: 14px; line-height: 1.7; border-top: 1px solid rgba(255,255,255,0.05); margin-top: 4px;" id="faq-answer-${idx}">
          ${item.answer}
        </div>
      </div>
    `
    )
    .join("");
}

window.toggleFaq = (idx) => {
  const ans = document.getElementById(`faq-answer-${idx}`);
  const icon = document.getElementById(`faq-icon-${idx}`);
  const card = document.getElementById(`faq-item-${idx}`);
  if (!ans || !icon) return;

  cyberAudio.playClick();
  const isOpen = ans.style.display === "block";

  if (isOpen) {
    ans.style.display = "none";
    icon.textContent = "+";
    icon.style.transform = "rotate(0deg)";
    if (card) card.style.borderColor = "var(--color-line)";
  } else {
    ans.style.display = "block";
    icon.textContent = "×";
    icon.style.transform = "rotate(45deg)";
    if (card) card.style.borderColor = "rgba(46,229,157,0.4)";
  }
};
