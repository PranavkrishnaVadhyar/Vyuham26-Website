/**
 * VYUHAM'26 TEAMS & SQUADS LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster, toast } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { authState } from "../lib/auth.js";
import { teamsApi } from "../lib/api.js";
import { cyberAudio } from "../lib/sound.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

let activeSquad = {
  name: "CyberVipers",
  code: "VYU-CYBER9",
  event: "Hackathon — 24HR",
  members: [
    { name: "Aromal S S", role: "Squad Leader", college: "Digital University Kerala", status: "CONFIRMED" },
    { name: "Neha Suresh", role: "Operative", college: "Digital University Kerala", status: "CONFIRMED" },
    { name: "Rahul Krishna", role: "Operative", college: "CET Trivandrum", status: "CONFIRMED" },
    { name: "Open Slot", role: "Unassigned", college: "Invite pending...", status: "INVITE READY" },
  ],
};

document.addEventListener("DOMContentLoaded", () => {
  setupForms();
  renderRoster();
  setupCopyCode();
});

function setupCopyCode() {
  const btn = document.getElementById("copy-code-btn");
  if (!btn) return;
  btn.addEventListener("click", () => {
    navigator.clipboard.writeText(activeSquad.code).then(() => {
      cyberAudio.playClick();
      toast(`Squad code ${activeSquad.code} copied to clipboard!`, "ok");
    });
  });
}

function renderRoster() {
  const nameEl = document.getElementById("active-squad-name");
  const codeBtn = document.getElementById("copy-code-btn");
  const listEl = document.getElementById("squad-members-list");
  if (!listEl) return;

  if (nameEl) nameEl.textContent = activeSquad.name;
  if (codeBtn) codeBtn.textContent = `${activeSquad.code} 📋`;

  listEl.innerHTML = activeSquad.members
    .map(
      (m, idx) => `
      <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 4px; padding: 12px 16px;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <strong style="color: #fff; font-size: 14px;">${m.name}</strong>
            <span class="font-mono text-xs text-mint" style="font-size: 10px;">${m.role}</span>
          </div>
          <span class="font-mono text-xs text-muted" style="display: block; margin-top: 2px;">${m.college}</span>
        </div>
        <span class="font-mono text-xs" style="padding: 2px 8px; border-radius: 4px; border: 1px solid ${m.status === "CONFIRMED" ? "#2ee59d" : "#f59e0b"}; color: ${m.status === "CONFIRMED" ? "#2ee59d" : "#f59e0b"}; font-size: 10px;">
          ${m.status}
        </span>
      </div>
    `
    )
    .join("");
}

function setupForms() {
  const createForm = document.getElementById("create-squad-form");
  const nameInput = document.getElementById("squad-name-input");
  const joinForm = document.getElementById("join-squad-form");
  const codeInput = document.getElementById("squad-code-input");

  if (createForm) {
    createForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const val = nameInput?.value.trim();
      if (!val) return;

      const user = authState.getUser();
      const myName = user?.name || "ME";
      const code = `VYU-${Math.floor(100 + Math.random() * 900)}`;

      activeSquad = {
        name: val,
        code,
        event: "Hackathon — 24HR",
        members: [
          { name: myName, role: "Squad Leader", college: user?.college || "Digital University Kerala", status: "CONFIRMED" },
          { name: "Open Slot", role: "Unassigned", college: "Invite pending...", status: "INVITE READY" },
        ],
      };

      try {
        await teamsApi.create({ name: val, code });
      } catch (err) {}

      cyberAudio.playAccessGranted();
      toast(`Squad "${val}" formed! Invite code: ${code}`, "ok");
      renderRoster();
      nameInput.value = "";
    });
  }

  if (joinForm) {
    joinForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const code = codeInput?.value.trim().toUpperCase();
      if (!code) return;

      try {
        await teamsApi.join(code);
      } catch (err) {}

      cyberAudio.playAccessGranted();
      toast(`Joined squad via invite code ${code}!`, "ok");
      codeInput.value = "";
    });
  }
}
