/**
 * VYUHAM'26 CERTIFICATES LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster, toast } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { authState } from "../lib/auth.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

const certificatesData = [
  {
    id: "CERT-VYU-90421",
    event: "Hackathon — 24HR",
    stream: "TECH",
    participantName: "Aromal S S",
    role: "1ST PLACE WINNER",
    status: "ISSUED & VERIFIED",
    date: "01 NOV 2026",
  },
  {
    id: "CERT-VYU-90422",
    event: "Capture The Flag",
    stream: "TECH",
    participantName: "Aromal S S",
    role: "RUNNER-UP SQUAD",
    status: "ISSUED & VERIFIED",
    date: "31 OCT 2026",
  },
  {
    id: "CERT-VYU-90423",
    event: "Prompt War",
    stream: "TECH",
    participantName: "Aromal S S",
    role: "MERIT OF PARTICIPATION",
    status: "ISSUED & VERIFIED",
    date: "31 OCT 2026",
  },
  {
    id: "CERT-VYU-90424",
    event: "Best Manager",
    stream: "MANAGEMENT",
    participantName: "Aromal S S",
    role: "FINALIST",
    status: "ISSUED & VERIFIED",
    date: "30 OCT 2026",
  },
];

document.addEventListener("DOMContentLoaded", () => {
  const user = authState.getUser();
  if (user?.name) {
    certificatesData.forEach((c) => {
      c.participantName = user.name;
    });
  }

  renderCertificates(certificatesData);
  setupSearch();
});

function setupSearch() {
  const form = document.getElementById("cert-search-form");
  const input = document.getElementById("cert-search-input");
  if (!form || !input) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = input.value.trim().toLowerCase();
    const filtered = certificatesData.filter(
      (c) =>
        c.id.toLowerCase().includes(q) ||
        c.event.toLowerCase().includes(q) ||
        c.participantName.toLowerCase().includes(q) ||
        c.role.toLowerCase().includes(q)
    );
    renderCertificates(filtered);
    toast(`Found ${filtered.length} certificate credential(s)`, "info");
  });
}

function renderCertificates(list) {
  const grid = document.getElementById("certificates-grid");
  if (!grid) return;

  if (list.length === 0) {
    grid.innerHTML = `<div style="grid-column: span 2; padding: 48px; text-align: center; color: var(--color-muted); font-family: var(--font-mono);">No certificate credentials found matching search criteria.</div>`;
    return;
  }

  grid.innerHTML = list
    .map(
      (cert) => `
      <div class="glass-card" style="padding: 28px; border: 1px solid rgba(24,196,124,0.3); background: rgba(11,20,16,0.7); position: relative; overflow: hidden;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px dashed rgba(255,255,255,0.15); padding-bottom: 16px; margin-bottom: 20px;">
          <div>
            <span class="font-mono text-xs uppercase" style="color: var(--color-emerald); letter-spacing: 0.05em;">DIGITAL UNIVERSITY KERALA</span>
            <h3 style="font-size: 20px; font-weight: 800; color: #fff; margin-top: 4px;">CERTIFICATE OF EXCELLENCE</h3>
          </div>
          <span class="font-mono text-xs" style="padding: 3px 8px; border-radius: 4px; background: rgba(46,229,157,0.15); border: 1px solid #2ee59d; color: #2ee59d;">
            ${cert.status}
          </span>
        </div>

        <div class="font-mono" style="font-size: 13px; line-height: 1.8; color: var(--color-bone);">
          <div>CREDENTIAL ID: <strong style="color: #fff;">${cert.id}</strong></div>
          <div>RECIPIENT: <strong style="color: var(--color-emerald); font-size: 15px;">${cert.participantName}</strong></div>
          <div>COMPETITION: <strong>${cert.event} (${cert.stream})</strong></div>
          <div>CITATION / RANK: <strong style="color: #fff;">${cert.role}</strong></div>
          <div>DATE OF ISSUE: <strong>${cert.date}</strong></div>
        </div>

        <div style="margin-top: 24px; padding-top: 16px; border-top: 1px solid var(--color-line); display: flex; justify-content: space-between; align-items: center;">
          <span class="font-mono text-xs text-muted">SIGNATURE: SHA-256 VALIDATED</span>
          <button class="btn btn-primary" style="padding: 8px 16px; font-size: 11px;" onclick="window.downloadCert('${cert.id}')">
            DOWNLOAD PDF ↓
          </button>
        </div>
      </div>
    `
    )
    .join("");
}

window.downloadCert = (id) => {
  toast(`Exporting cryptographically sealed PDF for ${id}...`, "ok");
};
