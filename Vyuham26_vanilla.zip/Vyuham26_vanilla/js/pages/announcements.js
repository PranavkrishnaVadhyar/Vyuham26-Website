/**
 * VYUHAM'26 ANNOUNCEMENTS FEED LOGIC
 */

import { renderNav } from "../components/nav.js";
import { renderFooter } from "../components/footer.js";
import { initToaster } from "../components/toaster.js";
import { initAuthModal } from "../components/auth-modal.js";
import { initCyberTerminal } from "../components/cyber-terminal.js";
import { initBroadcastTicker } from "../components/broadcast-ticker.js";
import { announcementsApi } from "../lib/api.js";

renderNav();
renderFooter();
initToaster();
initAuthModal();
initCyberTerminal();
initBroadcastTicker();

const defaultAnnouncements = [
  {
    id: "01",
    priority: "CRITICAL ALERT",
    title: "CAPTURE THE FLAG // ROUND 02 COMMENCING",
    time: "10 MIN AGO",
    stream: "TECH",
    content: "All registered CTF teams are requested to report to the Central Computing Lab by 11:15 AM for network credential allocation and environment provisioning.",
    accent: "#2ee59d",
  },
  {
    id: "02",
    priority: "SYSTEM UPDATE",
    title: "CAMPUS SHUTTLE TRANSPORT GRID ACTIVE",
    time: "01 HR AGO",
    stream: "GENERAL",
    content: "Transit units are operating every 15 minutes between the DUK Main Academic Block, Technocity Guest House, and Food Court zones.",
    accent: "#00e5ff",
  },
  {
    id: "03",
    priority: "CULTURAL ALERT",
    title: "FASHION SHOW // RUNWAY CALL BRIEFING",
    time: "02 HRS AGO",
    stream: "CULTURAL",
    content: "Open call runway briefing starts at the Open Air Amphitheatre. Student designers and model squads report to backstage Green Room 02.",
    accent: "#d946ef",
  },
  {
    id: "04",
    priority: "ESPORTS NOTICE",
    title: "VALORANT LAN QUALIFIERS // BRACKET RELEASED",
    time: "03 HRS AGO",
    stream: "ESPORTS",
    content: "The Swiss bracket schedule is published. Squad leaders check your registered Discord channels for room keys and veto order.",
    accent: "#f59e0b",
  },
];

document.addEventListener("DOMContentLoaded", async () => {
  const feed = document.getElementById("announcements-feed");
  if (!feed) return;

  let notices = defaultAnnouncements;
  try {
    const list = await announcementsApi.list();
    if (Array.isArray(list) && list.length > 0) {
      notices = list.map((item, idx) => ({
        id: String(idx + 1).padStart(2, "0"),
        priority: item.urgent ? "CRITICAL ALERT" : item.pinned ? "PINNED TRANSMISSION" : "SYSTEM UPDATE",
        title: item.title,
        time: item.created_at ? new Date(item.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "JUST NOW",
        stream: (item.stream || "GENERAL").toUpperCase(),
        content: item.content,
        accent: item.urgent ? "#ef4444" : "#2ee59d",
      }));
    }
  } catch (e) {}

  feed.innerHTML = notices
    .map(
      (notice) => `
      <div class="glass-card" style="padding: 24px; border: 1px solid var(--color-line); border-left: 4px solid ${notice.accent};">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; font-family: var(--font-mono); font-size: 11px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="color: ${notice.accent}; font-weight: 700;">${notice.priority}</span>
            <span style="color: var(--color-line);">//</span>
            <span class="text-muted">${notice.stream}</span>
          </div>
          <span class="text-muted">${notice.time}</span>
        </div>

        <h3 style="font-size: 18px; font-weight: 700; color: #fff; margin-bottom: 8px;">
          ${notice.title}
        </h3>

        <p style="font-family: var(--font-mono); font-size: 13px; color: var(--color-bone); line-height: 1.6;">
          ${notice.content}
        </p>
      </div>
    `
    )
    .join("");
});
