/**
 * VYUHAM'26 MEDIA ASSET REGISTRY (Vanilla JS)
 */
export const MEDIA = {
  heroVideo: "https://videos.pexels.com/video-files/29686188/12767975_1920_1080_30fps.mp4",
  heroPoster: "https://images.pexels.com/videos/29686188/abstract-black-chaotic-close-up-29686188.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
  campusNight: "https://images.pexels.com/photos/32120505/pexels-photo-32120505.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  campusFigure: "https://images.pexels.com/photos/36707300/pexels-photo-36707300.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  tower: "https://images.pexels.com/photos/33072178/pexels-photo-33072178.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  tunnel: "https://images.pexels.com/photos/15056137/pexels-photo-15056137.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  streetLight: "https://images.pexels.com/photos/10995856/pexels-photo-10995856.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  lab: "https://images.pexels.com/photos/3861960/pexels-photo-3861960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  electronics: "https://images.pexels.com/photos/34007253/pexels-photo-34007253.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  stage: "https://images.pexels.com/photos/20407014/pexels-photo-20407014.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  crowd: "https://images.pexels.com/photos/3727146/pexels-photo-3727146.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  dancerSilhouette: "https://images.pexels.com/photos/28825952/pexels-photo-28825952.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  esports: "https://images.pexels.com/photos/9072336/pexels-photo-9072336.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600"
};
