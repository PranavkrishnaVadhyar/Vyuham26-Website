import { useState } from "react";
import { cn } from "@/utils/cn";
import { useAuth } from "@/context/AuthContext";

let returnPathOverride: string | null = null;

/**
 * Make the next Google sign-in return to `path` instead of the button's default,
 * e.g. the event a user was viewing when the login modal opened. Pass null to clear.
 */
export function setAuthReturnPath(path: string | null) {
  returnPathOverride = path;
}

interface GoogleSignInButtonProps {
  /** App route to land on after Google sign-in (users with an incomplete profile go to /profile instead). */
  redirectPath?: string;
  onError?: (message: string) => void;
  label?: string;
  className?: string;
  disabled?: boolean;
}

export default function GoogleSignInButton({
  redirectPath = "/dashboard",
  onError,
  label = "CONTINUE WITH GOOGLE",
  className,
  disabled = false,
}: GoogleSignInButtonProps) {
  const { loginWithGoogle } = useAuth();
  const [pending, setPending] = useState(false);

  const handleClick = async () => {
    setPending(true);
    try {
      const res = await loginWithGoogle(returnPathOverride ?? redirectPath);
      // On success the browser is already navigating to Google.
      if (res.success === false) {
        setPending(false);
        onError?.(res.error || "Google sign-in failed.");
      }
    } catch {
      setPending(false);
      onError?.("Google sign-in could not be started. Please try again.");
    }
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={pending || disabled}
      aria-busy={pending}
      className={cn(
        "flex w-full items-center justify-center gap-3 border border-white/15 bg-black/30 px-4 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-paper transition-all duration-300 hover:border-green/50 hover:bg-green/[0.035] disabled:cursor-wait disabled:opacity-60",
        className,
      )}
    >
      <svg aria-hidden="true" width="16" height="16" viewBox="0 0 48 48">
        <path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.9z" />
        <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
        <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z" />
        <path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.7-.4-3.9z" />
      </svg>
      {pending ? (
        <>
          <span aria-hidden="true" className="h-3 w-3 animate-spin rounded-full border border-[#18c47c]/30 border-t-[#18c47c]" />
          REDIRECTING...
        </>
      ) : label}
    </button>
  );
}

/** "OR" separator between the Google button and the email form. */
export function AuthDivider() {
  return (
    <div className="flex items-center gap-3 font-mono text-[8px] uppercase tracking-[0.2em] text-muted">
      <span className="h-px flex-1 bg-white/10" />
      or
      <span className="h-px flex-1 bg-white/10" />
    </div>
  );
}
