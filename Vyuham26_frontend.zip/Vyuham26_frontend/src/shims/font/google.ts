export * from "../next-font";
